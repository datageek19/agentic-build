#!/usr/bin/env python3
"""Render every artifact for every environment and package an immutable bundle.

BUILD ONCE, DEPLOY MANY - and render at BUILD time, not deploy time.
PROD deploys a pre-rendered file that the TEST run already exercised, so
"worked in TEST, different in PROD" is structurally impossible.

This script never opens a Snowflake connection. The stage that transforms code
is deliberately incapable of touching the database.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from lib import config, manifest as mf, render  # noqa: E402

REPO = Path(__file__).resolve().parents[1]
ENVIRONMENTS = ("dev", "test", "prod")


def _env_token_values(environment: str, *, shape_only: bool) -> dict:
    """Token values for one environment.

    shape_only=True substitutes placeholders so the render can be validated
    with no secrets present - which lets the offline PR job run on any branch,
    including a fork.
    """
    if shape_only:
        import yaml as _yaml
        common = _yaml.safe_load(
            (REPO / "configuration" / "common.yaml").read_text())
        env_raw = _yaml.safe_load(
            (REPO / "configuration" / "environments"
             / f"{environment}.yaml").read_text())
        # Binding completeness must be checked even without secrets, or a
        # token missing from one environment file survives the PR gate and
        # fails on release night instead.
        bound = set(env_raw.get("tokens") or {})
        required = {k for k, v in common["tokens"].items() if v.get("required")}
        missing = sorted(required - bound)
        if missing:
            raise SystemExit(
                f"FATAL {environment}.yaml does not bind required token(s) "
                f"{missing}")
        return {k: f"PLACEHOLDER_{k.upper()}_{environment.upper()}"
                for k in common["tokens"]}
    cfg = config.load(environment)
    return dict(cfg.tokens)


def build(*, environments, version, commit, builder, out_dir, shape_only):
    manifest = mf.load()
    out = Path(out_dir)
    lock = {
        "bundle_version": version,
        "git_commit": commit,
        "built_at": datetime.now(timezone.utc).isoformat(),
        "built_by": builder,
        "environments": list(environments),
        "artifacts": [],
    }

    token_values = {e: _env_token_values(e, shape_only=shape_only)
                    for e in environments}

    for art in sorted(manifest.artifacts, key=lambda a: (a.phase, a.order)):
        src = REPO / art.source
        if not src.exists():
            raise SystemExit(f"FATAL: manifest source not found: {art.source}")
        text = src.read_text()

        entry = {
            "logical_name": art.logical_name,
            "type": art.type,
            "source": art.source,
            "phase": art.phase,
            "order": art.order,
            "depends_on": art.depends_on,
            "source_contract": art.source_contract,
            "target_schema": {},
            "rendered_sha256": {},
        }

        for env in environments:
            vals = token_values[env]
            is_yaml = art.type in (mf.SEMANTIC_VIEW, mf.CORTEX_AGENT)
            rendered = render.render(text, vals, path=art.source,
                                     validate_yaml=is_yaml)

            # S02: the stored procedure names the object from the YAML, so a
            # manifest that claims another name would silently create the
            # wrong object.
            if art.type == mf.SEMANTIC_VIEW:
                declared = __import__("yaml").safe_load(rendered)["name"]
                if declared != art.logical_name:
                    raise SystemExit(
                        f"FATAL {art.source}: manifest logical_name "
                        f"'{art.logical_name}' != YAML name '{declared}'. "
                        f"SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML uses the YAML "
                        f"name; this would create the wrong object.")

            dest = out / "rendered" / env / art.source
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(rendered)

            entry["rendered_sha256"][env] = mf.sha256_text(rendered)
            if art.target:
                entry["target_schema"][env] = (
                    f"{vals[art.target['database_token']]}."
                    f"{vals[art.target['schema_token']]}")

        lock["artifacts"].append(entry)

    for extra in ("dependencies/manifest.yaml",
                  "dependencies/source_contracts.yaml",
                  "tests/preconditions", "tests/smoke", "tests/golden"):
        srcp = REPO / extra
        if srcp.is_dir():
            for f in srcp.rglob("*"):
                if f.is_file():
                    d = out / f.relative_to(REPO)
                    d.parent.mkdir(parents=True, exist_ok=True)
                    d.write_text(f.read_text())
        elif srcp.exists():
            d = out / extra
            d.parent.mkdir(parents=True, exist_ok=True)
            d.write_text(srcp.read_text())

    (out / "manifest.lock.json").write_text(json.dumps(lock, indent=2))
    (out / "provenance.json").write_text(json.dumps({
        "bundle_version": version, "git_commit": commit,
        "built_at": lock["built_at"], "built_by": builder,
        "artifact_count": len(lock["artifacts"]),
        "shape_only": shape_only,
    }, indent=2))
    return lock


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--environment", choices=ENVIRONMENTS)
    ap.add_argument("--all-environments", action="store_true")
    ap.add_argument("--version", default="0.0.0-local")
    ap.add_argument("--commit", default="local")
    ap.add_argument("--builder", default="local")
    ap.add_argument("--out", required=True)
    ap.add_argument("--dry-run", action="store_true",
                    help="render and validate; do not treat output as a bundle")
    ap.add_argument("--token-shape-only", action="store_true",
                    help="use placeholder token values; requires no secrets")
    args = ap.parse_args()

    envs = ENVIRONMENTS if args.all_environments else (args.environment,)
    if not envs or envs[0] is None:
        return int(bool(ap.error("--environment or --all-environments required")))

    lock = build(environments=envs, version=args.version, commit=args.commit,
                 builder=args.builder, out_dir=args.out,
                 shape_only=args.token_shape_only)

    print(f"rendered {len(lock['artifacts'])} artifact(s) for "
          f"{', '.join(envs)} -> {args.out}")
    for a in lock["artifacts"]:
        shas = " ".join(f"{e}={s[:8]}" for e, s in a["rendered_sha256"].items())
        print(f"  [{a['phase']:>2}/{a['order']:>2}] {a['logical_name']:38} {shas}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
