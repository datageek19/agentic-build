# Snowflake Semantic View CI/CD — Consolidated Implementation Package

Prepared for deployment of validated Snowflake semantic views and Cortex
Agents across DEV → TEST → PROD on Azure DevOps and GitHub Actions.

---

## 1. Executive deployment recommendation

**Deploy semantic views by calling `SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML`
from a single repository-owned Python script executed via the Snowflake Python
connector, with `verify_only => TRUE` as the pull-request gate. Azure DevOps
and GitHub Actions are thin wrappers containing no deployment logic.**

Source of truth: tokenised `.sv.yaml`. Transport: Python connector.
Orchestration: the CI platform. Validation: the platform itself.

Why this and not the alternatives:

1. **Every component is GA.** No production path depends on a preview feature.
2. **It is the only option with a real pre-deployment gate.** `verify_only`
   parses the YAML, resolves base-table references and validates column
   identifiers without creating anything — turning a mistyped column from a
   production incident into a failed pull request.
3. **YAML is what the humans produce and review.** Snowsight and Cortex Code
   emit YAML. Making DDL the source of truth inserts generated code between
   the modeller and the reviewer; a diff over 106 dimensions and their
   synonyms is materially easier to review in YAML than in generated DDL.
4. **Environment promotion collapses to one small problem.** The target schema
   is a runtime *argument* to the procedure and the object name comes from the
   YAML `name` field, so the view's location needs no templating. Only
   `base_table` references and verified-query SQL literals are substituted.
5. **Grants are preserved unconditionally.** On the YAML path a replace copies
   grants from the previous object, so no pipeline author can silently strip
   consumer access.
6. **It works everywhere** — separate accounts, private networking, any build
   agent, no dependency on Snowflake reaching the Git host.
7. **One implementation, two CI systems.** The behavioural contract is Python,
   testable locally; the platforms differ only in secrets and approvals.

Accepted trade-offs, stated plainly:

- No dependency-graph solver — ordering is explicit in the manifest.
  Acceptable: all semantic views are mutually independent; only agents depend
  on views.
- No state store, so removing an artifact does not drop the object. A
  decommission is a deliberate, gated `DROP`.
- Rollback is roll-forward: redeploy the previous known-good bundle.

**Roadmap, not a competing design.** Re-evaluate DCM Projects
(`DEFINE SEMANTIC VIEW`) once it reaches GA. The architecture is deliberately
structured so that swap replaces one module; the manifest, environment
configuration and validation suite carry over unchanged.

---

## 2. Verified Snowflake deployment mechanism

Capability status is Snowflake's own labelling, verified against official
documentation.

| Capability | Status | Used here |
|---|---|---|
| `CREATE OR REPLACE SEMANTIC VIEW` | **GA** | Yes, indirectly |
| `CREATE OR ALTER SEMANTIC VIEW` | **GA** | Available via `create_or_alter` |
| `ALTER SEMANTIC VIEW` | **GA**, comment only | No — cannot express model change |
| `SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML` | **GA** | **Primary mechanism** |
| `SYSTEM$READ_YAML_FROM_SEMANTIC_VIEW` | **GA** | Drift detection, snapshots |
| `GET_DDL('SEMANTIC_VIEW', …)` | **GA** | Snapshots, `generated/ddl/` |
| Python connector / JDBC / ODBC / SQL API | **GA** | Python connector |
| Snowflake REST API for semantic views | **NOT SUPPORTED** | — |
| Workload identity federation (OIDC) | **GA** | **Primary authentication** |
| Native Git integration (`EXECUTE IMMEDIATE FROM`) | GA, public internet only | Rejected — enterprise repos are private |
| DCM Projects `DEFINE SEMANTIC VIEW` | **PREVIEW** | Roadmap only |
| Terraform `snowflake_semantic_view` | **PREVIEW** | Rejected |
| dbt `dbt_semantic_view` | Snowflake Labs, no SLA | Rejected |
| Schema clone / account replication | GA | Rejected — promotes drift, not reviewed code |
| Bulk YAML→view conversion | **NOT SUPPORTED** | Scripted in series |

### Four constraints that bind the whole design

**C1 — No incremental change path.** Apart from comments, a semantic view
cannot be altered; it must be recreated. Every deployment is therefore a full
reconciliation. Idempotency is intrinsic, drift self-corrects, and the
diff-computation value that Terraform or DCM normally add is largely
neutralised for this object type.

**C2 — Target schema is a runtime argument; object name comes from the file.**
This is the most useful fact for promotion: the target needs no templating.
It also means a manifest claiming a different name would silently create the
wrong object — enforced by static check S02 and by `build.py`.

**C3 — Grant behaviour differs by format.** The YAML path always copies
grants; DDL requires an explicit `COPY GRANTS`. Unconditional preservation is
a safety property where PROD grants are administered by another team.

**C4 — Replacing requires `OWNERSHIP`.** The CI role must own every view it
deploys, in every environment. Any view hand-created by a named user blocks
the pipeline until ownership is transferred — a `SECURITYADMIN` operation the
pipeline cannot perform. Surfaced as precondition P08 with a copy-pasteable
remediation.

### Layer separation

| Layer | Status here |
|---|---|
| Semantic view DDL | Not authored. Captured to `generated/ddl/` as review and audit evidence |
| YAML semantic model | **Source of truth**, as a native semantic-view specification |
| Legacy stage-based YAML | **Not used.** Backward-compatibility only per Snowflake |
| Cortex Analyst configuration | Custom instructions and verified queries live *inside* the view; consumer access is Phase 30 grants |
| Cortex Code (CoCo) artifacts | **Development-time only.** `cortex-project.yaml` is a developer-local file, not a pipeline input, and Cortex Code is not a build-agent dependency |

The two authoring formats are not mixed: YAML is the only authored format, and
DDL appears only as generated output.

---

## 3. DEV–TEST–PROD promotion architecture

```
feature/* ──PR──▶ main ──tag v*──▶ TEST ──approval──▶ PROD

(1) PR validation      T0 static (offline) + T1 verify_only (read-only role)
(3) Build              renders DEV+TEST+PROD; NO Snowflake access at all
(4) DEV deploy         auto on merge; changed-only reconcile
(5) DEV validation     smoke, drift, grants
(6) TEST deploy        auto on tag; snapshot; changed-only
(7) TEST validation    + verified queries + accuracy gate (blocking)
(8) PROD deploy        manual; 2 approvals; change request; FULL reconcile
(9) PROD validation    full suite, blocking; ledger write
```

**Key architectural choices**

| Concern | Decision | Rationale |
|---|---|---|
| Branching | Trunk-based, short-lived branches, squash merge | A 43 KB machine-generated model cannot be safely three-way merged; `.gitattributes` forces a conflict instead of a silent corruption |
| Build/deploy split | Build once, **render at build time** for all three environments | PROD deploys a pre-rendered file TEST already exercised, so "worked in TEST, different in PROD" is structurally impossible |
| Change detection | sha256 of the **rendered** artifact, keyed per environment, stored in Snowflake | Hashing source files misses a config change that repoints every `base_table` without touching a model |
| PROD reconcile | Always full | Replacement is atomic and idempotent, so redeploying unchanged views is free and guarantees convergence |
| Dependency order | Explicit phases with hard barriers | A failed view must block **all** agent deployment: an agent on a stale layer degrades silently rather than erroring |
| Concurrency | One deploy per environment; never cancel | Cancelling mid-phase-20 leaves a mixed-version layer |
| Ledger | Snowflake table, append-only by privilege | Survives CI migration; queryable by the platform team without pipeline access |
| Rollback | Roll-forward from the previous bundle | Snowflake's documented approach; RTO in seconds |

---

## 4. Repository structure

Neutrality codes: **N** identical everywhere · **NT** neutral but tokenised ·
**E** one file per environment · **G** generated, never hand-edited.

| Path | Purpose | Neutral | Env values from | Phase | Origin |
|---|---|---|---|---|---|
| `semantic_views/**/*.sv.yaml` | Semantic model — source of truth | NT | `${land_source_db}` etc. at build | 20 | Manual |
| `agents/*.agent.yaml` | Cortex Agent specification | NT | `${target_db_bi}` etc. | 40 | Manual |
| `dependencies/manifest.yaml` | Deployment contract | N | token *references* only | drives all | Manual |
| `dependencies/source_contracts.yaml` | Base tables, columns, PII register | NT | source tokens | 00 | Manual |
| `grants/30_semantic_view_grants.sql.j2` | View grants | NT | roles/objects from env config | 30 | Manual |
| `grants/50_agent_grants.sql.j2` | Agent grants | NT | same | 50 | Manual |
| `configuration/common.yaml` | Token registry, policy | N | — | — | Manual |
| `configuration/environments/*.yaml` | **Variable-binding manifest** — no identifiers | E | declares `{from_env: …}` | — | Manual |
| `configuration/config.toml` | CLI connection stub, deliberately empty | N | — | — | Manual |
| `bootstrap/*.sql` | One-time roles, containers, grants | NT | CLI `-D` variables | pre-1 | Manual |
| `scripts/lib/*.py` | Config, render, manifest, session, ledger | N | — | — | Manual |
| `scripts/build.py` | Render all environments, package bundle | N | — | (3) | Manual |
| `scripts/verify.py` | `verify_only` gate | N | — | (2) | Manual |
| `scripts/deploy.py` | Phase-ordered deployment | N | — | 00–50 | Manual |
| `scripts/validate.py` | Post-deploy and drift suites | N | — | 60 | Manual |
| `scripts/snapshot.py` | Pre-deploy state capture | N | — | pre-20 | Manual |
| `scripts/rollback.py` | Roll-forward / snapshot restore | N | — | on demand | Manual |
| `scripts/breakglass_unlock.py` | Stale lock release | N | — | on demand | Manual |
| `tests/policy/` | T0 static gate | N | — | (1) | Manual |
| `tests/preconditions/`, `tests/smoke/` | SQL reference forms for triage | NT | tokens | 00 / 60 | Manual |
| `tests/golden/` | Accuracy cases and thresholds | N | — | 60 | Manual |
| `generated/ddl/` | `GET_DDL` export, per environment | **G** | n/a | — | **CI** |
| `generated/snapshots/` | Pre-deploy YAML exports | **G** | n/a | — | **CI** |
| `azure-pipelines/`, `.github/workflows/` | Wrappers only | N | secret stores | — | Manual |
| `CODEOWNERS` | Dual review; security review on the source contract | N | — | — | Manual |
| `.gitattributes` | `*.sv.yaml merge=binary` | N | — | — | Manual |

**Only `configuration/environments/*.yaml` differs between environments — and
even those contain no identifiers, only variable names.**

---

## 5–8. Scripts, configuration, and pipelines

These are the shipped files, not excerpts. See the repository tree.

| Requirement | Artifact |
|---|---|
| Semantic View deployment scripts | `scripts/deploy.py`, `scripts/build.py`, `scripts/verify.py`, `scripts/lib/*.py` |
| Environment configuration | `configuration/common.yaml`, `configuration/environments/{dev,test,prod}.yaml`, `configuration/config.toml` |
| Azure DevOps pipeline | `azure-pipelines/azure-pipelines.yml` + 5 templates |
| GitHub Actions workflows | `.github/workflows/`: `pr-validation`, `_build`, `_deploy`, `cd-dev`, `cd-test`, `cd-prod`, `drift-detect` |

### Semantic View DDL — representative generated form

Authored input is YAML; this is what the deployment produces, captured by
`GET_DDL` into `generated/ddl/<env>/`:

```sql
-- GENERATED BY CI - DO NOT EDIT
create or replace semantic view SV_LAND_PARTICIPATION_INTERESTS
  tables (
    QUORUM_QLREPORT_QDV_PARTICIPATION as <SOURCE_DB>.<SOURCE_SCHEMA>.QUORUM_QLREPORT_QDV_PARTICIPATION
      primary key (DESG_KEY),
    QUORUM_QLREPORT_QDV_AGMT_HDR as <SOURCE_DB>.<SOURCE_SCHEMA>.QUORUM_QLREPORT_QDV_AGMT_HDR
      primary key (ARRG_KEY)
  )
  relationships (
    PARTICIPATION_TO_AGMT as
      QUORUM_QLREPORT_QDV_PARTICIPATION (ARRG_KEY)
      references QUORUM_QLREPORT_QDV_AGMT_HDR (ARRG_KEY)
  )
  facts (
    QUORUM_QLREPORT_QDV_PARTICIPATION.PCT_INT as PCT_INT
      with synonyms = ('percent interest','participation percent')
  )
  metrics (
    QUORUM_QLREPORT_QDV_PARTICIPATION.TOTAL_PARTICIPATION_INTEREST as
      SUM(CASE WHEN ACTIVE_IND ILIKE 'Y' THEN PCT_INT ELSE NULL END)
  );
```

### Rendering is raw-text, not a YAML round trip

`scripts/lib/render.py` substitutes over bytes then parses once only to
validate. A PyYAML round trip would reorder keys, normalise quoting, reflow
106 synonym lists and strip comments — destroying the reviewability that
motivated choosing YAML in the first place.

### Azure DevOps ↔ GitHub Actions parity

| Concern | Azure DevOps | GitHub Actions | Equivalent |
|---|---|---|---|
| Deployment logic | `scripts/` | `scripts/` | Identical code |
| Auth | `ConfigureSnowflakeCLI@0` + service connection | `snowflakedb/snowflake-actions` + OIDC | Both WIF |
| Reuse | YAML templates | reusable workflows | Yes |
| Approvals | Environment approvals and checks | Environment required reviewers | Yes |
| Serialisation | Exclusive Lock | job `concurrency` | Yes |
| Runtime change-request input | Pipeline parameters | `workflow_dispatch` inputs | Yes (`cd-prod.yml`) |
| Business-hours gate | Business Hours check | **no native equivalent** | Gap — script a guard, or accept the wait timer |
| Required-template check | Required template check | **no native equivalent** | Gap — mitigated by `CODEOWNERS` + environment-scoped OIDC |
| Test reporting | `PublishTestResults@2` | `$GITHUB_STEP_SUMMARY` + artifact | Comparable; ADO richer |

GitHub is stronger in one respect: with an environment-scoped OIDC subject,
**the approval gates the credential rather than the deployment step.** A
workflow edited to skip the approval cannot obtain a token PROD will accept.

---

## 9. Authentication and secret management

**Target state: zero long-lived secrets.** Workload identity federation is
Snowflake's recommended method for `TYPE = SERVICE` users, and it removes the
need to store passwords, API keys or key pairs.

| Item | Storage | Rotation |
|---|---|---|
| Snowflake authentication | **none** — OIDC token, per job | n/a |
| `SF_ACCOUNT`, DB/schema/role names | Key Vault (ADO) / environment secret (GHA) | on change |
| `SF_PRIVATE_KEY_RAW` (fallback only) | Key Vault, RSA-4096 | 90 days, dual-key overlap |
| Entra federated credential | Entra ID; **no client secret exists** | n/a |

Enforced properties: `config.toml` committed empty (static check S05); one
service identity per function per environment; no cross-environment credential
grants; `session.py` never formats connection parameters into an exception,
because CI masking does not cover values a script prints itself; passwords are
unsupported by construction.

### Security trade-offs

| Decision | Chosen | Trade-off |
|---|---|---|
| Auth method | WIF / OIDC | No secret to leak; but a hard dependency on a third-party action in the credential path, and claim-mismatch debugging is opaque until the token is decoded |
| Subject scope | `environment:` for TEST/PROD | Approval gates the credential; but the environment name becomes load-bearing security config — renaming it breaks auth in a way that looks like a config bug |
| Secret placement | Environment secrets | Repository secrets are readable by any workflow, so a PR job could exfiltrate PROD credentials. Cost: nine-way duplication |
| PR trigger | `pull_request` | Denies secrets to fork PRs. `pull_request_target` would grant them to fork code — a known escalation vector. Cost: fork PRs skip T1 |
| Default permissions | `permissions: {}` | A compromised step cannot push or comment. Cost: every need declared explicitly |
| Action pinning | Full commit SHA recommended | Tags are mutable by the publisher. Cost: unreadable diffs; needs Dependabot |
| `cancel-in-progress` | `false` on deploys | No half-reconciled layers. Cost: queuing |
| Artifact retention | 400 days | The bundle is the rollback record. Cost: storage; org limit must be raised |
| Key-pair fallback | Present, disabled | Survives a blocked marketplace extension. Cost: audit that the secret is genuinely empty |

**Residual risk to name explicitly:** a workflow change and a Snowflake
privilege change are reviewed by different people through different processes.
With environment-scoped subjects, someone with repo write access still cannot
reach PROD without triggering the approval. The remaining gap is an approver
who approves without reading the diff — mitigated by `CODEOWNERS` on
`.github/workflows/**` and "require review of the most recent push".

---

## 10. Role and grant model

```
        ACCOUNTADMIN                        ← humans, break-glass only
     ┌───────┴────────┐
SECURITYADMIN      SYSADMIN                 ← humans, bootstrap only
     │                  │
     │        R_SEMANTIC_ADMIN_<ENV>        ← container owner
     │                  │
     │        R_SEMANTIC_DEPLOY_<ENV>       ← CI write: CREATE SEMANTIC VIEW
     │                                        on ONE schema + OWNERSHIP
R_SEMANTIC_GRANTOR_<ENV>                    ← MANAGE GRANTS on the schema only
R_SEMANTIC_VALIDATE_<ENV>                   ← CI read
R_SEMANTIC_CONSUMER_LAND_<ENV>              ← Analyst / agent / BI runtime
R_SEMANTIC_BREAKGLASS_<ENV>                 ← named human, time-boxed
```

**The pipeline never holds `ACCOUNTADMIN`, `SECURITYADMIN` or `SYSADMIN`.**

**Object creation is separated from grant administration.** If one identity
both created views and granted on them, a compromised CI run could create a
view over any readable table and grant itself access to the result. The split
costs one service user per environment and is the highest-value control here.
`WITH MANAGED ACCESS` on the target schemas enforces it in Snowflake rather
than by role hygiene.

**Owner's rights is the security boundary.** A consumer holding `SELECT` on a
view needs no base-table access, so the deploy role's base-table grants define
the maximum data surface reachable through the semantic layer. Therefore:
grants are **enumerated per table** (never `FUTURE TABLES` in a source
schema), and `dependencies/source_contracts.yaml` carries a `CODEOWNERS`
security review.

**Future grants:** `FUTURE SEMANTIC VIEWS` in the target schema — yes.
`FUTURE TABLES` in a source schema — never.

**Ownership transfer is permanently a human operation.** Container-level
`MANAGE GRANTS` explicitly cannot transfer ownership, and the pipeline holds
nothing higher. P08 converts this into a clean precondition failure.

**Sample values are unmasked metadata.** `GET_DDL` exposes them verbatim
regardless of masking policies, so static check S22 blocks `sample_values` on
any column in the PII register. The supplied model has none today, but the
Snowsight wizard adds them by default.

---

## 11. Validation framework

Four tiers, each with a distinct identity and cost profile.

| Tier | Where | Identity | Cost |
|---|---|---|---|
| T0 static | PR, offline | none | zero |
| T1 native verify | PR + Phase 00 | validate role | metadata |
| T2 pre-deployment | Phase 00, before any write | deploy role | metadata |
| T3 post-deployment | Phase 60 | deploy + validate | warehouse |

**Design principle: do not reimplement `verify_only`.** It already catches
invalid YAML with line and column, non-existent base tables, invalid column
identifiers including in primary keys, and expression compilation. T0 and T2
cover only what it cannot see.

### T0 static — 61 checks, all offline

S01 YAML well-formed · S02 manifest/name agreement · S03 manifest uniqueness
and target collision · S04 naming standard · S05 no hard-coded environment
references, `config.toml` empty · S06 tokens declared and used · **S06b every
environment binds every required token** · S06c manifest target tokens
declared · S08 DAG, no forward phase dependency · S09 source-contract coverage
· S10 duplicate members · S11 duplicate relationships · S12 relationships
named · S13 relationship column integrity · S14 right-side join key declared
*(grace)* · S15 orphan tables *(grace)* · S19 no version strings in
descriptions · S22 no `sample_values` on PII.

### T2 pre-deployment — zero writes on failure

P01 `verify_only` · P02/P03 base tables and columns · P05 target schemas ·
P07 `CREATE SEMANTIC VIEW` · **P08 `OWNERSHIP`** · P09 base-table `SELECT` ·
**P10 join-column type compatibility** · P11 declared keys actually unique ·
P13 advisory lock · P14 consumer roles exist.

P10 is the one real gap `verify_only` leaves: Snowflake accepts a relationship
joining `VARCHAR` to `NUMBER`. The view compiles and then silently returns
nothing. This matters for cross-domain keys such as `API10`, which is modelled
as `VARCHAR` in one system and often `NUMBER` in another.

P11 is cheap and catches errors that produce plausible-but-wrong values: a
duplicate primary key inflates every metric joining through it.

### T3 post-deployment

D01 existence · D02–D04 member inventory via `SHOW SEMANTIC DIMENSIONS /
FACTS / METRICS` · **D05 structural equality** via
`SYSTEM$READ_YAML_FROM_SEMANTIC_VIEW` normalised against the bundle · D06
grant matrix · D07/D08 representative `SEMANTIC_VIEW()` queries with range
assertions · D09 Cortex privilege assertion · D10 verified-query replay ·
D11/D12 golden accuracy and per-question regression · D13 cross-environment
structural equality · D15 ledger written.

D05 is the strongest single check: it proves what is deployed is what was
reviewed. It is also the nightly drift detector — same function, different
schedule.

D14 compares **ratios, not absolutes**. TEST usually holds a subset of PROD
data; comparing row counts produces failures engineers learn to ignore, which
is worse than no check.

### Blocking matrix

| Check | PR | DEV | TEST | PROD |
|---|---|---|---|---|
| S01–S06c, S08–S13, S19, S22 | **Block** | Block | Block | Block |
| S14, S15 (orphan, key) | Warn | Warn | Warn | Warn → Block |
| P01 `verify_only` | **Block** | **Block** | **Block** | **Block** |
| P05–P09 privileges, ownership | — | **Block** | **Block** | **Block** |
| P10 type family mismatch | Warn | **Block** | **Block** | **Block** |
| P11 key uniqueness | — | Warn | Warn | **Block** |
| D01–D05 | — | **Block** | **Block** | **Block** |
| D06 missing grant | — | Warn | **Block** | **Block** |
| D06 unexpected grant | — | Warn | Warn | **Block** |
| D07 compiles / D08 empty | — | Block / Warn | **Block** | **Block** |
| D09 privilege / live round trip | — | Block / Warn | Block / Warn | Block / Warn |
| D10 verified queries | — | Warn | **Block** | **Block** |
| D11 accuracy ≥ threshold | — | Warn (0.70) | **Block** (0.90) | **Block** (0.90) |
| D12 per-question regression | — | Warn | **Block** | **Block** |
| D13 cross-env structure | — | — | **Block** | **Block** |
| D15 ledger | — | **Block** | **Block** | **Block** |

Thresholds: golden pass rate ≥ 90% in TEST and PROD, ≥ 70% non-blocking in
DEV; **zero tolerance** on per-question regression; 100% verified-query replay;
warning budget 10 per view, exceeding it fails the stage to prevent
warning-blindness.

**No retries on semantic failures** — transient SQLSTATEs only. Retrying a
failed `verify_only` produces a flaky suite people re-run until green.

**Quarantine expires.** Each entry in `tests/golden/quarantine.yaml` needs an
owner, reason and an expiry ≤ 30 days; an expired entry is itself a blocking
failure. Otherwise quarantine becomes where failures go to be forgotten and
the 90% threshold silently becomes 90% of a shrinking denominator.

---

## 12. Cortex Analyst validation approach

Cortex Analyst configuration is not a separate deployable: custom
instructions and verified queries live inside the semantic view and deploy
with it. Validation therefore has four layers.

1. **Structural** — D02–D04 assert every dimension, fact and metric the model
   declares is actually present. A renamed metric does not error; it silently
   stops being available and Analyst answers a slightly different question.
2. **Access** — D09 asserts each consumer role holds
   `SNOWFLAKE.CORTEX_ANALYST_USER` (not the broader `CORTEX_USER`).
   **Plus the agent exception:** Cortex Agents require the executing role to
   hold `SELECT` on both the semantic view *and* its underlying tables. Owner's
   rights covers direct view querying but **not** the agent path.
3. **Behavioural** — D10 replays the curated verified queries. Analyst treats
   these as worked examples, so a verified query that stops returning rows is
   itself an accuracy regression.
4. **Accuracy** — D11/D12 run the golden set. Assertions are on SQL
   *semantics*, not exact text, because generated SQL varies between runs:
   which tables were referenced, which filters applied, which operator used,
   which patterns forbidden. This turns the model's own custom instruction
   ("use `ILIKE`, not `UPPER()` with `LIKE`") from documentation into an
   enforced test.

**Diagnosing a regression** — the cause determines whether rollback helps:

| Cause | Rollback helps? |
|---|---|
| Renamed member, changed metric expression | **Yes** |
| Custom instruction change | **Yes** |
| Verified query removed or broken | **Yes** |
| Base data changed (new agreement types, shifted distributions) | **No** — forward fix |
| Snowflake-side LLM change | **No** — nothing in the bundle changed |

Separate the last case by re-running the golden set against the *unchanged*
previous bundle. If N−1 also fails now, it is not your regression.

---

## 13. Rollback / roll-forward

**Transactional rollback is not available and is not claimed.** DDL
auto-commits; no transaction spans several `CALL` statements. `CREATE OR
REPLACE` is atomic **per object** only, so no view is ever internally
inconsistent, but a mid-phase failure leaves a mixed-version layer.

| Pattern | Verdict |
|---|---|
| Transactional rollback | **Rejected — not supported** |
| Redeploy prior version | **PRIMARY** — Snowflake's documented approach |
| `CREATE OR REPLACE` | Mechanism, not a strategy |
| Versioned objects + alias switching | **Rejected** — no alias construct exists; emulating it means rewriting every agent's tool resources, converting a one-object rollback into a multi-object one with no transaction |
| Forward-fix migration | **SECONDARY**, and required when the model itself is wrong |
| Snapshot restore | **Break-glass only** |

Decision rule: if the deployed definition differs from Git it is a deployment
defect → roll back. If it matches Git, the model is wrong → fix forward.
**A removed source column is forward-fix only** — the prior version references
the same missing column.

**RTO is seconds.** A semantic view is metadata over unchanged base tables;
four views revert in under a minute. Say this to stakeholders explicitly,
because intuition from table-level DDL rollback is far more pessimistic and
drives unnecessarily conservative change windows.

Full procedure in `docs/RUNBOOK.md`.

---

## 14. Production deployment checklist

### One-time enablement

- [ ] `bootstrap/01`–`04` executed in each account by a human
- [ ] `NP_CI_EGRESS` network policy created and applied to all service users
- [ ] Entra App Registrations (ADO) or GitHub environments created per environment
- [ ] Snowflake service users' `WORKLOAD_IDENTITY` subject matches the platform exactly
- [ ] `snow connection test` succeeds from a pipeline run in every environment
- [ ] `OWNERSHIP` transferred with `COPY CURRENT GRANTS` for every pre-existing view
- [ ] Base-table `SELECT` granted, enumerated, by the source data owner
- [ ] Agent base-table access decision made (see UNRESOLVED-3)
- [ ] `WITH MANAGED ACCESS` verified end-to-end in DEV before PROD
- [ ] Artifact retention raised to ≥ 400 days
- [ ] `CODEOWNERS` handles replaced; branch protection on `main` (2 reviewers, squash, build validation)
- [ ] PROD environment: 2 approvers, self-review prevented, admin bypass **off**, tags-only, Exclusive Lock / concurrency
- [ ] **Rollback rehearsed in TEST**: deploy N, deploy N+1, roll back to N, confirm grants and agent routing survived, record the elapsed time

### Per release

- [ ] All T0 static checks green
- [ ] T1 `verify_only` green for every view
- [ ] 2 PR approvals including a domain owner
- [ ] Semver bumped correctly (**major** for any removed or renamed member)
- [ ] Tag `v<x.y.z>` on `main`; build artifact published with checksum
- [ ] TEST deployed from that tag; snapshot captured
- [ ] TEST validation green: smoke, drift, grants, verified queries, accuracy ≥ 0.90
- [ ] Zero per-question regressions versus the previous bundle
- [ ] Change request raised and approved; ID matches `^(CHG|CR)-[0-9]{4,}$`
- [ ] Deployment inside the change window
- [ ] PROD: 2 approvals recorded
- [ ] Phase 00 preconditions passed (zero writes if not)
- [ ] Pre-deploy snapshot captured and published
- [ ] Full reconcile confirmed in the log (`reconcile: full`)
- [ ] PROD validation green; ledger row written with the change-request ID
- [ ] `generated/ddl/prod/` committed by CI
- [ ] Evidence artifact published and retained

### Post release

- [ ] Ledger state matches the intended bundle for every artifact
- [ ] Overnight drift detection clean
- [ ] Warning count within budget
- [ ] Any new failure mode added as a golden case

---

## 15. Troubleshooting runbook

See `docs/RUNBOOK.md` — severity model, five-minute triage, decision tree,
scenario index (nine scenarios), rollback procedure, on-call reference card,
break-glass index, escalation boundaries, post-incident requirements.

---

## 16. Assumptions, limitations, unresolved items

### Assumptions

| # | Assumption | If wrong |
|---|---|---|
| A1 | Each environment has its own Snowflake account **or** its own database set within one account | Isolation model in §10 needs revisiting; cloning becomes an option for same-account promotion |
| A2 | Source tables exist and are readable in every environment | Preconditions fail with zero writes; source strategy must be decided first |
| A3 | The CI service role can be made owner of every managed view | P08 blocks until ownership is transferred |
| A4 | Marketplace extensions / third-party actions are installable | Key-pair fallback path, already wired |
| A5 | Semver discipline is followed for member removals | D02–D04 and D12 still catch it, but only after the fact |
| A6 | No materializations in use | Set `create_or_alter: true` before introducing any |

### Limitations

| # | Limitation | Consequence |
|---|---|---|
| L1 | No multi-object DDL transaction | Partial deployment is real; converge in one direction |
| L2 | No Time Travel or `UNDROP` for semantic views | Snapshots are the only recovery for a dropped view |
| L3 | No incremental `ALTER` | Every deploy is a full replace |
| L4 | Semantic views cannot join each other | Cross-domain joins are agent-layer routing |
| L5 | Snowflake REST API unsupported for semantic views | SQL API / connector only |
| L6 | No bulk YAML conversion | Serial loop; watch wall clock past a few dozen views |
| L7 | Sample values are unmasked metadata | S22 blocks them on PII |
| L8 | Snowsight edits are destroyed by the next deploy | No human `CREATE SEMANTIC VIEW` in TEST/PROD |
| L9 | Removing a manifest entry does not drop the object | Decommission is a separate gated action |
| L10 | No native business-hours or required-template check on GitHub | Script a guard; use `CODEOWNERS` |

### Unresolved items — must close before first PROD deployment

| # | Item | Owner | Blocks |
|---|---|---|---|
| **UNRESOLVED-1** | Three of four semantic models are stubs; participation is abridged to 4 of 10 tables. Supply the real exports | Domain owner | Any deployment beyond DEV |
| **UNRESOLVED-2** | Agent specification body shape is **inferred**, not verified. Confirm against the `CREATE AGENT` reference | Data engineering | Phase 40 |
| **UNRESOLVED-3** | **Cortex Agents require the executing role to hold `SELECT` on base tables as well as the view.** Choose option A, B or C (C recommended: base-table grants *plus* source-side row access and masking policies) | Source data owner + security | First PROD agent deployment |
| **UNRESOLVED-4** | Programmatic NL-to-SQL invocation path not confirmed, so D09 layer 2 and D11 report **WARN**. Spike in DEV, then promote to blocking | Data engineering | Accuracy gate being real |
| **UNRESOLVED-5** | Whether `verify_only` executes under a role lacking `CREATE SEMANTIC VIEW`. If not, use a disposable `DS_ENT_VALIDATE` schema — never widen the real target | Platform team | PR gate least-privilege claim |
| **UNRESOLVED-6** | Whether the Snowflake ADO marketplace extension is installable in the organisation | DevOps | ADO secretless auth |
| **UNRESOLVED-7** | Account topology: one account or three? | Platform team | Isolation model, rollback options |
| **UNRESOLVED-8** | Do source-side masking and row access policies already exist on the business-associate PII columns? If not, UNRESOLVED-3 option C is not achievable yet | Source data owner | PII protection posture |
| **UNRESOLVED-9** | Orphan logical table with unreachable metrics in the supplied model. Join it (likely `PROPERTY_NUMBER` → `COP_WI.PROPERTY_NUM`) or drop it. Currently S15 grace-period `xfail` | Domain owner | Recurring "returns nothing" tickets |
| **UNRESOLVED-10** | Managed access + owner's rights + grant copying interaction on replace — verify in DEV | Platform team | Enabling managed access in PROD |

### Explicitly marked inferred / unverified

- Cortex Agent specification body keys (`agents/*.agent.yaml`, `deploy_cortex_agent()`).
- `CREATE OR REPLACE AGENT … FROM SPECIFICATION` exact clause syntax.
- `GRANT USAGE ON AGENT` privilege name (`grants/50_agent_grants.sql.j2`).
- OPS source contract column list.
- Whether `verify_only` needs `CREATE SEMANTIC VIEW` (UNRESOLVED-5).

Everything else is grounded in official documentation (§17).

---

## 17. Supporting documentation

| Claim | Reference |
|---|---|
| Semantic views are schema-level objects; YAML specification | `docs.snowflake.com/en/user-guide/views-semantic/semantic-view-yaml-spec` |
| `CREATE OR REPLACE` is atomic; `CREATE OR ALTER` semantics | `/en/sql-reference/sql/create-semantic-view` |
| `ALTER SEMANTIC VIEW` changes comment only | `/en/sql-reference/sql/alter-semantic-view` |
| Procedure signature, `verify_only`, `create_or_alter`, grant copying, required privileges | `/en/sql-reference/stored-procedures/system_create_semantic_view_from_yaml` |
| No REST API; owner's rights; sample values unmasked; agent needs base-table SELECT; no bulk conversion; Snowsight overwrite; CI/CD and rollback guidance; cloning and replication; Terraform "planned"; dbt package | `/en/user-guide/views-semantic/best-practices-dev` |
| YAML vs DDL parity, `COPY GRANTS` difference, round-trip functions | `/en/user-guide/views-semantic/yaml-vs-ddl` |
| SQL usage, verified queries, `SEMANTIC_VIEW()` | `/en/user-guide/views-semantic/sql` |
| `CORTEX_USER` / `CORTEX_ANALYST_USER`; legacy stage YAML backward-compatible | `/en/user-guide/snowflake-cortex/cortex-analyst` |
| DCM Projects `DEFINE SEMANTIC VIEW` preview status and limitations; container `MANAGE GRANTS`; inherited grants | `/en/user-guide/dcm-projects/dcm-projects-supported-entities` |
| WIF concepts, `WORKLOAD_IDENTITY`, service users | `/en/user-guide/workload-identity-federation` |
| Python connector `authenticator=WORKLOAD_IDENTITY`, `workload_identity_provider`, `token` | `/en/developer-guide/python-connector/python-connector-connect` |
| ADO `ConfigureSnowflakeCLI@0`, GitHub `snowflake-actions`, OIDC claim formats, env-var precedence, CLI ≥ 3.11 | `snowflake.com/en/developers/guides/configure-cicd-integrations-with-snowflake/` |
| Terraform provider preview status | `registry.terraform.io/providers/snowflakedb/snowflake/latest/docs/resources/semantic_view` |
| Git integration public-internet limitation | Snowflake DevOps / Git integration docs |
| SnowSQL maintenance-only posture | `/en/user-guide/snowsql` |

---

## 18. Traceability matrix

| Requirement | Implementation artifact | Validation control |
|---|---|---|
| Verified deployment mechanism | `scripts/deploy.py::deploy_semantic_view` | P01, D01, D05 |
| Environment-neutral definitions | `semantic_views/**`, `scripts/lib/render.py` | S05, S06, S06b, S06c |
| Environment substitution | `configuration/environments/*.yaml`, `build.py` | S06b, render test, D13 |
| No hard-coded identifiers | `configuration/config.toml` empty; token registry | S05, audit rule 9 |
| DEV→TEST→PROD promotion | `azure-pipelines.yml`, `cd-dev/test/prod.yml` | stage graph; ledger D15 |
| Branching / PR strategy | `.gitattributes`, `CODEOWNERS`, branch protection | S20, 2 approvals |
| Required approvals | Environment approvals; `require-change-request` | change-request regex |
| Deployment triggers | `trigger`/`pr`/`on:` blocks | — |
| Environment protection | Environments, branch/tag rules, Exclusive Lock, concurrency | P13 advisory lock |
| Build/deploy separation | `stage-build.yml`, `_build.yml` (no `id-token`) | bundle checksum |
| Artifact versioning | `manifest.lock.json`, `provenance.json`, semver from tag | sha256 verify |
| Change detection | rendered-sha vs ledger, `manifest.plan()` | D05 |
| Dependency ordering | `manifest.yaml` phases; hard barriers in `deploy.py` | S08, audit rule 2 |
| Concurrency control | CI concurrency + `ledger.advisory_lock` | P13 |
| Failure handling | phase barrier, grant error aggregation, retry on transient only | evidence `if: always()` |
| Auditability | `SEMANTIC_DEPLOYMENT_LOG`, `QUERY_TAG`, artifacts, Git | D15 |
| Rollback / roll-forward | `rollback.py`, `snapshot.py` | post-rollback validation |
| Static validation | `tests/policy/test_repo_policy.py` (61 checks) | T0 gate |
| Pre-deployment validation | `deploy.py::phase_00_preconditions`, `tests/preconditions/` | P01–P14 |
| Post-deployment validation | `validate.py` (5 suites), `tests/smoke/` | D01–D15 |
| Cortex Analyst validation | `suite_golden`, `tests/golden/` | D09–D12 |
| CI/CD service identity | `bootstrap/01` service users | audit rule 5 |
| Deployment role | `R_SEMANTIC_DEPLOY_<ENV>`, `bootstrap/02` | P07 |
| Semantic view owner role | Deploy role owns; managed access schemas | P08 |
| Cortex runtime role | `R_SEMANTIC_CONSUMER_LAND_<ENV>`, `bootstrap/04` | D09 |
| Consumer roles | `grants/30_*.sql.j2` | D06 |
| Underlying table access | `bootstrap/03`, enumerated | P09, S09 |
| Future grants | `FUTURE SEMANTIC VIEWS` only | D06 |
| Ownership transfer | `bootstrap` + runbook; never automated | P08 |
| Managed access schemas | `bootstrap/02` `WITH MANAGED ACCESS` | UNRESOLVED-10 |
| Least privilege | `bootstrap/01`–`02`; DEPLOY/GRANTOR split | audit rule 5 |
| Secret management | Environment secrets, WIF, `session.py` | S05 |
| Environment isolation | Per-env users, roles, subjects, secret scopes | audit rules 4, 6 |
| Credential rotation | §9; dual-key overlap | quarterly attestation |
| Break-glass | `breakglass_unlock.py`, `R_SEMANTIC_BREAKGLASS_<ENV>` | ledger rows |
| Production change approval | 2 approvers + change request + tag-only + quality gate | regex, D11, D12 |
| Deployment logs | `--log-json`, evidence artifacts, `$GITHUB_STEP_SUMMARY` | `if: always()` |
| ADO/GHA equivalence | Shared `scripts/`; thin wrappers | audit rule 8 |

---

## 19. Final consistency audit

Automated across filenames, variables, roles, environment names, commands and
deployment ordering.

| # | Audit rule | Result |
|---|---|---|
| 1 | Every manifest source exists; `logical_name` == YAML `name` | **PASS** |
| 2 | Phase set `{20,30,40,50}`; no dependency crosses a phase forward | **PASS** |
| 3 | Token registry == every environment binding == usage ∪ manifest targets | **PASS** |
| 4 | Every `from_env` variable is set by both pipelines; all 12 per-env build variables present | **PASS** |
| 5 | All six roles and three service users defined; no broad admin role granted to any service user | **PASS** |
| 6 | Environment names consistent (`sf-dev`, `sf-test`, `sf-prod`, `sf-dev-verify`) | **PASS** |
| 7 | Every script invoked by a pipeline exists and declares every flag used | **PASS** |
| 8 | ADO/GHA parity on all nine functional tokens | **PASS** |
| 9 | No hard-coded organisation identifier in any non-comment line | **PASS** |

**0 failures, 1 informational warning** — `ACCOUNTADMIN` appears once in
`bootstrap/01_roles_and_users.sql` line 4, inside the comment asserting that
the pipeline is never granted it. Benign.

### Executable self-verification

```
T0 static gate                61 checks, 0 failures, 0 xfail
Render all environments       7 artifacts × 3 environments, distinct per-env shas
Negative tests (8 injected defects, all blocked):
  manifest/YAML name mismatch      → BLOCKED (dependency integrity)
  duplicate manifest target        → BLOCKED (S03)
  hard-coded environment database  → BLOCKED (S05)
  undeclared token typo            → BLOCKED (S06)
  sample_values on PII             → BLOCKED (S22)
  relationship on undeclared column→ BLOCKED (S13)
  manifest dependency cycle        → BLOCKED (S08)
  token missing from prod.yaml only→ BLOCKED (S06b + build)
Python syntax                 13/13 modules parse
YAML syntax                   all pipeline, config, model and manifest files parse
```

The last negative test found a genuine gap during construction: the offline
render check bypassed environment-binding validation, so a token missing from
`prod.yaml` alone would have survived the pull-request gate and failed at
release. Fixed by adding S06b and a binding assertion inside
`build.py --token-shape-only`.
