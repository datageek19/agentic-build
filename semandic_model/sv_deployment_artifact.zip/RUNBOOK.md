# Operational runbook

## Severity

| Sev | Definition | Response | First action |
|---|---|---|---|
| 1 | Agent unavailable, or answering wrongly to business users | Page on-call | Roll back to last good bundle |
| 2 | One view broken; agent partially degraded | Same business day | Assess, then roll back or fix forward |
| 3 | Deployment failed, prior version still serving | Next business day | Diagnose; no user impact |
| 4 | Drift, warnings, quality below target but functional | Next sprint | Ticket |

A failed deployment where the prior version still serves is **Sev 3, not
Sev 1**. `CREATE OR REPLACE` is atomic per object, so a failed deploy leaves
working state. Most panic in this system comes from reading a red pipeline as
an outage.

## Transactional reality

- **Per object: atomic.** `CREATE OR REPLACE` deletes the old object and
  creates the new one in a single transaction. No view is ever half-replaced.
- **Across objects: not transactional.** DDL auto-commits. There is no
  `BEGIN … ROLLBACK` spanning four `CALL` statements. Partial deployment is a
  real state to be handled, not prevented.
- **No Time Travel or `UNDROP`** for semantic views. Snapshots are the only
  recovery path for a dropped view.
- **Recovery is seconds.** A semantic view is metadata over unchanged base
  tables. Four views roll back in under a minute.

## Triage — first five minutes

```bash
# 1. What is live, per view?
python scripts/lib/ledger.py state --environment prod

# 2. Is it structurally what Git says?
python scripts/validate.py --environment prod --suite drift --report /tmp/drift.json

# 3. Does it answer questions?
python scripts/validate.py --environment prod --suite smoke,verified_queries

# 4. Who touched it last, and was it us?
snow sql -q "
  SELECT start_time, user_name, role_name, query_type, LEFT(query_text,150)
  FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
  WHERE query_type ILIKE '%SEMANTIC_VIEW%'
    AND start_time > DATEADD('hour',-24,CURRENT_TIMESTAMP())
  ORDER BY start_time DESC"
```

Step 4 answers the question that determines everything else: was this a
deployment, or did someone edit the environment by hand?

## Decision tree

```
Are users affected?
├── NO  → Sev 3. Prior version is serving. Diagnose at leisure.
└── YES
    ├── Live state ≠ Git (drift check failed)?
    │   └── YES → out-of-band edit
    │            → redeploy current bundle --force; open a finding
    └── Live state = Git?
        ├── Source column disappeared (P03/drift)?
        │   └── YES → FORWARD FIX ONLY. Rollback cannot help: the prior
        │            version references the same missing column.
        ├── Mixed versions in the ledger (partial deployment)?
        │   └── YES → converge in ONE direction. Forward if the cause is
        │            understood, backward if not. Never leave it mixed.
        └── Otherwise → ROLL BACK, then fix forward.
```

## Scenario index

| Scenario | Pattern | Notes |
|---|---|---|
| Failed deployment | Converge forward, or roll back | Phase 40 never ran, so no agent was rewired |
| Invalid definition | Fix forward | Should never pass the PR gate; if it did, the gate is broken |
| Missing dependencies | Fix environment, re-run | Phase 00 failure means **zero writes** |
| Missing grant | Re-run Phase 30 only | Idempotent, no view replacement |
| Unexpected grant | Revoke, then re-check D06 | Grant copying makes it permanent otherwise |
| Breaking metric/dimension change | Roll back, then deprecate over two releases | Nothing errors; the member silently stops being available |
| Renamed/removed source column | **Forward fix only** | Rollback references the same missing column |
| Cortex Analyst regression | Depends on cause | Re-run golden set against bundle N−1 to separate your regression from a platform change |
| Partial deployment | Converge one direction with `--force` | Usually benign — views do not join to each other |
| Concurrent attempts | Wait, or break-glass unlock | `breakglass_unlock.py --confirm-run-dead` |

## Rollback procedure (Sev 1)

```bash
# 1. Identify the target. Do not guess.
python scripts/lib/ledger.py history --environment prod --limit 10

# 2. Retrieve the bundle (400-day retention).
gh run download <build-run-id> -n semantic-layer-1.3.2-7b2e4d1
tar -xzf semantic-layer-1.3.2-7b2e4d1.tgz

# 3. Execute.
python scripts/rollback.py \
  --environment prod \
  --to-version 1.3.2 \
  --bundle bundle \
  --reason "Sev1: TOTAL_PARTICIPATION_INTEREST exceeding 100%" \
  --change-request CHG-1234

# 4. Verify.
python scripts/validate.py --environment prod \
  --suite smoke,drift,grants,verified_queries --blocking

# 5. MANDATORY — reconcile Git to the environment.
gh pr create --title "Revert semantic layer to 1.3.2" \
  --body "Rollback of 1.4.0 per INC-nnnn."
```

**Step 5 is the step that gets skipped and causes the repeat incident.** If
PROD is at 1.3.2 while `main` is at 1.4.0, the next unrelated release
redeploys the broken change. `rollback.py` prints this on exit.

## On-call reference card

| Symptom | Likely cause | First command |
|---|---|---|
| Red, Phase 00 | Missing grant, table or ownership | Read the failure; it names the object and the remediation |
| Red, Phase 20 | Model defect or source change | `verify.py` locally |
| Red, Phase 30 | Grant target missing | `SHOW ROLES LIKE` |
| Red, Phase 40 | A view failed earlier — barrier held | Fix Phase 20 first |
| Red, Phase 60 | Quality gate | Per-question diff in the `--report` JSON |
| Agent: "I don't have that data" | Member renamed or removed | D02–D04 inventory |
| Agent: plausible but wrong | Non-unique join key, or metric change | P11 uniqueness check |
| Query returns zero rows | `ACTIVE_IND` filter, or type-mismatched join | P10 type check |
| Overnight drift issue | Snowsight edit, or source change | Triage step 4 |
| Deploy hangs | Lock contention or suspended warehouse | `ledger.py state`, `SHOW WAREHOUSES` |
| Auth suddenly fails | Repo/environment/service-connection renamed | README "load-bearing strings" |

## Break-glass

| Situation | Procedure |
|---|---|
| CI unavailable, PROD fix needed | Grant `R_SEMANTIC_BREAKGLASS_PROD` to a named human, time-boxed, two approvers. Deploy from the bundle YAML, never a hand-edit. Revoke within 24 h |
| Stale lock | `python scripts/breakglass_unlock.py --environment prod --incident INC-n --reason "..." --confirm-run-dead` |
| Ownership blocks deploy | `SECURITYADMIN`: `GRANT OWNERSHIP ON SEMANTIC VIEW <fqn> TO ROLE R_SEMANTIC_DEPLOY_<ENV> COPY CURRENT GRANTS` |
| Credential compromise | `ALTER USER … SET DISABLED = TRUE; ALTER USER … UNSET WORKLOAD_IDENTITY;` then scope via `QUERY_HISTORY` |
| Rollback target predates Git | `rollback.py --from-snapshot <dir>`, then commit the restored YAML |

All break-glass paths require an incident number, a reason, a ledger row, and
a retro within 24 hours.

## Escalation

| Boundary | Owner | Trigger |
|---|---|---|
| Semantic model, pipeline, bundles | Data engineering | Default |
| Snowflake account, roles, warehouses | Platform team | Privilege, ownership, account parameters |
| Source tables and columns | Source data owner | Any P02/P03/P09 failure |
| Cortex Analyst platform behaviour | Snowflake support | Golden set regresses on bundle N−1 too |
| Agent routing | Data engineering + platform jointly | Routing anomalies with all views healthy |
| CI platform | DevOps | Runner, marketplace, OIDC infrastructure |

## Post-incident

Within 24 h: Git reconciled; ledger complete with reason and incident number;
break-glass grants revoked; **a golden-set case added covering the failure
mode.** That last item is the one with compounding value — otherwise the
golden set only tests what someone imagined, never what has actually broken.

Within one week: retro covering which gate should have caught it, and a
decision on whether a static check moves from Warn to Block.
