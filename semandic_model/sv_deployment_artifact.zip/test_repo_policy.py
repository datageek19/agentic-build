"""T0 static validation. Runs entirely offline: no network, no credentials.

Deliberately does NOT reimplement what verify_only already does
(base-table existence, column resolution, expression compilation). It covers
only what the Snowflake procedure cannot see: manifest agreement, uniqueness,
naming, tokenisation, graph shape, and PII exposure via sample values.
"""
from __future__ import annotations

import re
import sys
from collections import Counter
from pathlib import Path

import pytest
import yaml

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "scripts"))

from lib import manifest as mf, render  # noqa: E402

MODELS = sorted((REPO / "semantic_views").rglob("*.sv.yaml"))
AGENTS = sorted((REPO / "agents").rglob("*.agent.yaml"))
MANIFEST = mf.load()
COMMON = yaml.safe_load((REPO / "configuration" / "common.yaml").read_text())
CONTRACTS = yaml.safe_load(
    (REPO / "dependencies" / "source_contracts.yaml").read_text())
ENVIRONMENTS = ("dev", "test", "prod")

SV_NAME = re.compile(r"^SV_[A-Z0-9_]{3,60}$")
BANNED_NAME = re.compile(r"(^ZZ_|_VERSION\d+$|^(ACN|EVS|TMP|WIP)_)")
ENV_LEAK = re.compile(r"\b[A-Z][A-Z0-9_]{2,}_(DEV|TEST|QA|STG|STAGE|PRD|PROD)\b")

IDS = staticmethod(lambda p: p.name)


# ------------------------------------------------------------------ S01
@pytest.mark.parametrize("path", MODELS + AGENTS, ids=lambda p: p.name)
def test_s01_yaml_wellformed(path):
    assert isinstance(yaml.safe_load(path.read_text()), dict)


# ------------------------------------------------------------------ S02
@pytest.mark.parametrize("path", MODELS, ids=lambda p: p.name)
def test_s02_manifest_name_agreement(path):
    rel = str(path.relative_to(REPO))
    entry = MANIFEST.by_source(rel)
    assert entry, f"{rel} has no manifest entry"
    declared = yaml.safe_load(path.read_text())["name"]
    assert entry.logical_name == declared, (
        f"{rel}: manifest says '{entry.logical_name}' but YAML declares "
        f"'{declared}'. SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML takes the object "
        f"name from the YAML, so this would silently create the wrong object.")


# ------------------------------------------------------------------ S03
def test_s03_manifest_uniqueness():
    for field in ("logical_name", "source"):
        vals = [getattr(a, field) for a in MANIFEST.artifacts]
        dupes = sorted({v for v in vals if vals.count(v) > 1})
        assert not dupes, f"duplicate {field}: {dupes}"

    targets = Counter(
        (a.target["database_token"], a.target["schema_token"], a.logical_name)
        for a in MANIFEST.artifacts if a.target)
    collisions = [t for t, n in targets.items() if n > 1]
    assert not collisions, f"multiple artifacts resolve to one target: {collisions}"


# ------------------------------------------------------------------ S04
@pytest.mark.parametrize("path", MODELS, ids=lambda p: p.name)
def test_s04_naming_standard(path):
    name = yaml.safe_load(path.read_text())["name"]
    assert SV_NAME.match(name), f"{name} does not match ^SV_[A-Z0-9_]{{3,60}}$"
    assert not BANNED_NAME.search(name), (
        f"{name} uses sandbox or vendor naming; not promotable")


# ------------------------------------------------------------------ S05
@pytest.mark.parametrize("path", MODELS + AGENTS, ids=lambda p: p.name)
def test_s05_no_hardcoded_environment_refs(path):
    leaks = []
    for lineno, line in enumerate(path.read_text().splitlines(), 1):
        if line.lstrip().startswith("#"):
            continue
        for m in ENV_LEAK.finditer(line):
            leaks.append(f"line {lineno}: {m.group(0)}")
    assert not leaks, f"{path.name}: hard-coded environment references {leaks}"


def test_s05_config_toml_has_no_values():
    text = (REPO / "configuration" / "config.toml").read_text()
    body = [l for l in text.splitlines()
            if l.strip() and not l.strip().startswith("#")]
    for line in body:
        if line.startswith("[") or line.startswith("default_connection_name"):
            continue
        assert "=" not in line, (
            f"config.toml must contain no connection values; found: {line}")


# ------------------------------------------------------------------ S06
@pytest.mark.parametrize("path", MODELS + AGENTS, ids=lambda p: p.name)
def test_s06_tokens_declared_and_bound(path):
    used = render.used_tokens(path.read_text())
    declared = set(COMMON["tokens"])
    assert used <= declared, f"{path.name}: undeclared tokens {sorted(used - declared)}"
    for env in ENVIRONMENTS:
        bound = set(yaml.safe_load(
            (REPO / "configuration" / "environments" / f"{env}.yaml").read_text()
        )["tokens"])
        assert used <= bound, (
            f"{path.name}: tokens unbound in {env}: {sorted(used - bound)}")


# ------------------------------------------------------------------ S06b
@pytest.mark.parametrize("env", ENVIRONMENTS)
def test_s06b_environment_binds_every_required_token(env):
    """S06b. Catches the release-night failure mode that S06 cannot see: a
    required token absent from ONE environment file. S06 is parametrised over
    source files, so a token referenced only through a manifest target
    reference (e.g. target_db_exp) is invisible to it."""
    env_raw = yaml.safe_load(
        (REPO / "configuration" / "environments" / f"{env}.yaml").read_text())
    bound = set(env_raw.get("tokens") or {})
    required = {k for k, v in COMMON["tokens"].items() if v.get("required")}
    missing = sorted(required - bound)
    assert not missing, (
        f"{env}.yaml does not bind required token(s) {missing}. Every "
        f"environment must bind every declared token, or promotion to that "
        f"environment fails at deploy time instead of on this pull request.")
    extra = sorted(bound - set(COMMON["tokens"]))
    assert not extra, f"{env}.yaml binds undeclared token(s) {extra}"


def test_s06c_manifest_target_tokens_are_declared():
    """Every database_token/schema_token used by a manifest target must exist
    in the registry, so that build.py can always resolve a target schema."""
    declared = set(COMMON["tokens"])
    for a in MANIFEST.artifacts:
        if not a.target:
            continue
        for key in ("database_token", "schema_token"):
            tok = a.target[key]
            assert tok in declared, (
                f"{a.logical_name}: manifest target {key} '{tok}' is not "
                f"declared in configuration/common.yaml")


# ------------------------------------------------------------------ S08
def test_s08_manifest_graph_is_valid():
    mf.validate(MANIFEST.artifacts)   # raises on cycle or forward dependency


# ------------------------------------------------------------------ S09
@pytest.mark.parametrize("path", MODELS, ids=lambda p: p.name)
def test_s09_source_contract_coverage(path):
    rel = str(path.relative_to(REPO))
    entry = MANIFEST.by_source(rel)
    contract = CONTRACTS["contracts"].get(entry.source_contract)
    assert contract, f"{rel}: source_contract '{entry.source_contract}' unknown"
    contracted = {t["name"] for t in contract["tables"]}
    model = yaml.safe_load(path.read_text())
    used = {t["base_table"]["table"] for t in model["tables"]
            if "base_table" in t and "table" in t["base_table"]}
    assert used <= contracted, (
        f"{rel}: base tables absent from source_contracts.yaml: "
        f"{sorted(used - contracted)}")


# ------------------------------------------------------------------ S10/S11/S12
@pytest.mark.parametrize("path", MODELS, ids=lambda p: p.name)
def test_s10_s11_s12_no_duplicate_members(path):
    model = yaml.safe_load(path.read_text())
    for tbl in model["tables"]:
        local = [m["name"] for section in
                 ("dimensions", "time_dimensions", "facts", "metrics")
                 for m in (tbl.get(section) or [])]
        dupes = sorted({n for n in local if local.count(n) > 1})
        assert not dupes, f"{path.name}/{tbl['name']}: duplicate members {dupes}"

    rels = model.get("relationships") or []
    names = [r.get("name") for r in rels]
    assert all(names), f"{path.name}: unnamed relationship (S12)"
    dn = sorted({n for n in names if names.count(n) > 1})
    assert not dn, f"{path.name}: duplicate relationship names {dn}"

    shapes = [(r["left_table"], r["right_table"],
               tuple(sorted((c["left_column"], c["right_column"])
                            for c in r["relationship_columns"])))
              for r in rels]
    ds = [s for s in set(shapes) if shapes.count(s) > 1]
    assert not ds, f"{path.name}: duplicate relationship definitions {ds}"


# ------------------------------------------------------------------ S13
@pytest.mark.parametrize("path", MODELS, ids=lambda p: p.name)
def test_s13_relationship_integrity(path):
    model = yaml.safe_load(path.read_text())
    members = {}
    for tbl in model["tables"]:
        members[tbl["name"]] = {
            m["name"] for section in
            ("dimensions", "time_dimensions", "facts") 
            for m in (tbl.get(section) or [])}
    for rel in model.get("relationships") or []:
        for side in ("left_table", "right_table"):
            assert rel[side] in members, (
                f"{path.name}/{rel['name']}: {side} '{rel[side]}' "
                f"is not a declared logical table")
        for col in rel["relationship_columns"]:
            assert col["left_column"] in members[rel["left_table"]], (
                f"{path.name}/{rel['name']}: left_column "
                f"'{col['left_column']}' not declared on {rel['left_table']}")
            assert col["right_column"] in members[rel["right_table"]], (
                f"{path.name}/{rel['name']}: right_column "
                f"'{col['right_column']}' not declared on {rel['right_table']}")


# ------------------------------------------------------------------ S14 (grace)
@pytest.mark.parametrize("path", MODELS, ids=lambda p: p.name)
def test_s14_right_side_join_key_declared(path):
    model = yaml.safe_load(path.read_text())
    keys = {}
    for tbl in model["tables"]:
        declared = set(tbl.get("primary_key", {}).get("columns") or [])
        for uk in tbl.get("unique_keys") or []:
            declared |= set(uk.get("columns") or [])
        keys[tbl["name"]] = declared
    offenders = [
        f"{rel['name']} -> {rel['right_table']}"
        for rel in model.get("relationships") or []
        if not {c["right_column"] for c in rel["relationship_columns"]}
               <= keys.get(rel["right_table"], set())]
    if offenders:
        pytest.xfail(f"S14 grace period: right-side key not declared for "
                     f"{offenders}")


# ------------------------------------------------------------------ S15 (grace)
@pytest.mark.parametrize("path", MODELS, ids=lambda p: p.name)
def test_s15_no_orphan_logical_tables(path):
    model = yaml.safe_load(path.read_text())
    tables = {t["name"] for t in model["tables"]}
    if len(tables) == 1:
        return
    joined = set()
    for rel in model.get("relationships") or []:
        joined |= {rel["left_table"], rel["right_table"]}
    orphans = sorted(tables - joined)
    if orphans:
        pytest.xfail(f"S15 grace period: orphan logical tables {orphans} - "
                     f"their metrics are unreachable via any join path")


# ------------------------------------------------------------------ S19
@pytest.mark.parametrize("path", MODELS, ids=lambda p: p.name)
def test_s19_no_version_strings_in_descriptions(path):
    """Descriptions are Cortex Analyst prompt context. Injecting a bundle
    version or commit sha pollutes the prompt and degrades NL-to-SQL."""
    text = path.read_text()
    bad = re.findall(r"description:.*\b(v\d+\.\d+\.\d+|commit [0-9a-f]{7,})",
                     text, flags=re.IGNORECASE)
    assert not bad, f"{path.name}: version string in a description: {bad}"


# ------------------------------------------------------------------ S22
@pytest.mark.parametrize("path", MODELS, ids=lambda p: p.name)
def test_s22_no_sample_values_on_pii(path):
    """Sample values are stored as metadata and are NOT masked: GET_DDL on the
    view exposes them verbatim regardless of masking policies."""
    model = yaml.safe_load(path.read_text())
    pii = {c.split(".")[-1] for c in CONTRACTS.get("pii_columns") or []}
    offenders = []
    for tbl in model["tables"]:
        for section in ("dimensions", "time_dimensions", "facts"):
            for m in (tbl.get(section) or []):
                if m.get("sample_values") and (
                        m["name"] in pii or str(m.get("expr")) in pii):
                    offenders.append(f"{tbl['name']}.{m['name']}")
    assert not offenders, (
        f"{path.name}: sample_values present on PII columns {offenders}; "
        f"sample values are unmasked metadata")


# ------------------------------------------------------------------ S06 render
@pytest.mark.parametrize("env", ENVIRONMENTS)
def test_render_succeeds_for_every_environment(env):
    """A token missing from prod.yaml must fail on the PR, not on release night."""
    placeholders = {k: f"PLACEHOLDER_{k.upper()}" for k in COMMON["tokens"]}
    for path in MODELS + AGENTS:
        render.render(path.read_text(), placeholders,
                      path=str(path.relative_to(REPO)),
                      validate_yaml=True)
