# Bootstrap

Run once per Snowflake account, by a **human** holding SECURITYADMIN /
SYSADMIN. The pipeline never holds these roles and cannot run these scripts.

Order: `01` -> `02` -> `03` -> `04`.

All scripts take values as Snowflake CLI variables (`-D`), never literals.
Every `PLACEHOLDER_*` below must be populated from your organisation's
values; see docs/PLACEHOLDERS.md.

```bash
snow sql -f bootstrap/01_roles_and_users.sql \
  -D "env=PROD" \
  -D "tenant_id=$AZ_TENANT_ID" \
  -D "ado_org=$ADO_ORG" -D "ado_project=$ADO_PROJECT" \
  -D "svc_conn=sf-semantic-wif-prod" \
  -D "gh_org=$GH_ORG" -D "gh_repo=$GH_REPO" \
  -D "warehouse=$SF_WAREHOUSE" \
  -D "target_db=$SF_TARGET_DB_BI" -D "target_schema=$SF_TARGET_SCHEMA_BI" \
  -D "exp_db=$SF_TARGET_DB_EXP" -D "exp_schema=$SF_TARGET_SCHEMA_EXP" \
  -D "ci_platform=GITHUB"
```
