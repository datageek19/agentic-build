#!/usr/bin/env python3
"""Phase-ordered deployment of a built semantic-layer bundle.

Phases and barriers:
  00 preconditions  read-only assertions; any failure aborts with ZERO writes
  10 containers     idempotent, usually a no-op
  20 semantic views serial; ALL must succeed before phase 40
  30 view grants    convergence; collects all failures before failing
  40 cortex agents  hard dependency on phase 20
  50 agent grants
  60 validation     delegated to validate.py

There is no multi-object DDL transaction in Snowflake. CREATE OR REPLACE is
atomic PER OBJECT, so no view is ever internally inconsistent, but a failure
mid-phase-20 leaves a mixed-version layer. That state is handled by converging
in one direction (see rollback.py), never by an automated partial undo.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import yaml  # noqa: E402
from jinja2 import Template  # noqa: E402

from lib import config, ledger, manifest as mf, session  # noqa: E402

REPO = Path(__file__).resolve().parents[1]


class JsonLog:
    def __init__(self, path: str | None):
        self.fh = open(path, "a") if path else None

    def write(self, **kw):
        if self.fh:
            self.fh.write(json.dumps(kw) + "\n")
            self.fh.flush()

    def close(self):
        if self.fh:
            self.fh.close()


def _retry(cfg, fn):
    attempts = cfg.deploy["retry"]["attempts"]
    backoff = cfg.deploy["retry"]["backoff_seconds"]
    transient = set(cfg.deploy["retry"]["retry_on_sqlstate"])
    last = None
    for i in range(attempts):
        try:
            return fn()
        except Exception as exc:  # noqa: BLE001
            last = exc
            sqlstate = getattr(exc, "sqlstate", None)
            if sqlstate not in transient:
                raise  # never retry a semantic or privilege error
            if i < attempts - 1:
                time.sleep(backoff[min(i, len(backoff) - 1)])
    raise last


# ---------------------------------------------------------------- phase 00
def phase_00_preconditions(cur, cfg, manifest, bundle: Path) -> None:
    contracts = yaml.safe_load(
        (bundle / "dependencies" / "source_contracts.yaml").read_text()
    )["contracts"]
    failures: list[str] = []

    # P05 target schemas exist
    for fqn in (cfg.schema_bi_fqn, cfg.schema_exp_fqn):
        db, schema = fqn.split(".")
        cur.execute(
            f"SELECT COUNT(*) FROM {db}.INFORMATION_SCHEMA.SCHEMATA "
            "WHERE SCHEMA_NAME = %s", (schema,))
        if cur.fetchone()[0] == 0:
            failures.append(f"P05 target schema missing: {fqn}")

    # P02/P03 base tables and required columns
    for name, contract in contracts.items():
        db = cfg.token(contract["database_token"])
        schema = cfg.token(contract["schema_token"])
        for tbl in contract["tables"]:
            cols = tbl["required_columns"]
            placeholders = ",".join(["%s"] * len(cols))
            cur.execute(
                f"SELECT COUNT(*) FROM {db}.INFORMATION_SCHEMA.COLUMNS "
                "WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s "
                f"AND COLUMN_NAME IN ({placeholders})",
                (schema, tbl["name"], *cols))
            found = cur.fetchone()[0]
            if found != len(cols):
                failures.append(
                    f"P02/P03 {name}/{tbl['name']}: {found}/{len(cols)} "
                    f"required columns present in {db}.{schema}")

    # P07 CREATE SEMANTIC VIEW on the target schema
    cur.execute("SHOW GRANTS TO ROLE IDENTIFIER(%s)", (cfg.connection["role"],))
    grants = cur.fetchall()
    have_create = any(
        "CREATE SEMANTIC VIEW" in str(g[1]).upper()
        and cfg.schema_bi_fqn.upper() in str(g[3]).upper()
        for g in grants)
    if not have_create:
        failures.append(
            f"P07 role {cfg.connection['role']} lacks CREATE SEMANTIC VIEW "
            f"on {cfg.schema_bi_fqn}")

    # P08 OWNERSHIP of every pre-existing target view
    cur.execute(f"SHOW SEMANTIC VIEWS IN SCHEMA {cfg.schema_bi_fqn}")
    rows = cur.fetchall()
    cols = [d[0].lower() for d in cur.description]
    idx_name, idx_owner = cols.index("name"), cols.index("owner")
    expected = set(manifest.semantic_view_names)
    for r in rows:
        if r[idx_name] in expected and r[idx_owner] != cfg.connection["role"]:
            failures.append(
                f"P08 {r[idx_name]} is owned by {r[idx_owner]}; replacement "
                f"requires OWNERSHIP. Remediate:\n"
                f"    GRANT OWNERSHIP ON SEMANTIC VIEW "
                f"{cfg.schema_bi_fqn}.{r[idx_name]}\n"
                f"      TO ROLE {cfg.connection['role']} COPY CURRENT GRANTS;")

    # P14 consumer roles exist
    for role in cfg.consumer_roles:
        cur.execute("SHOW ROLES LIKE %s", (role,))
        if not cur.fetchall():
            failures.append(f"P14 consumer role does not exist: {role}")

    if failures:
        raise RuntimeError(
            "phase 00 preconditions failed; NO writes were performed:\n  - "
            + "\n  - ".join(failures))
    print("phase 00: all preconditions passed")


# ---------------------------------------------------------------- phase 20
def deploy_semantic_view(cur, cfg, art, text: str) -> str:
    def call():
        cur.execute(
            "CALL SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML(%s, %s, %s, %s)",
            (cfg.schema_bi_fqn, text, False, cfg.deploy["create_or_alter"]),
        )
        return cur.fetchone()[0]
    return _retry(cfg, call)


# ---------------------------------------------------------------- phase 40
def deploy_cortex_agent(cur, cfg, art, text: str) -> str:
    """CREATE OR REPLACE AGENT ... FROM SPECIFICATION $$ <yaml> $$.

    INFERRED: the exact specification body schema is not reproduced here.
    The file is passed through verbatim, so correcting its shape requires no
    change to this function. Confirm against the CREATE AGENT reference
    before enabling phase 40 in a gated environment.
    """
    fqn = f"{cfg.schema_exp_fqn}.{art.logical_name}"
    cur.execute(
        f"CREATE OR REPLACE AGENT {fqn} FROM SPECIFICATION $${text}$$")
    return f"agent {fqn} created"


# ---------------------------------------------------------------- phase 30/50
def run_grant_script(cur, cfg, art, text: str, manifest) -> str:
    rendered = Template(text).render(
        grantor_role=cfg.grantor_connection.get("role")
                     or cfg.connection["role"],
        warehouse=cfg.connection["warehouse"],
        consumer_warehouse=cfg.connection["warehouse"],
        consumer_roles=cfg.consumer_roles,
        semantic_views=manifest.semantic_view_names,
        cortex_agents=manifest.cortex_agent_names,
        target_db_bi=cfg.token("target_db_bi"),
        target_schema_bi=cfg.token("target_schema_bi"),
        target_db_exp=cfg.token("target_db_exp"),
        target_schema_exp=cfg.token("target_schema_exp"),
    )
    statements = [s.strip() for s in rendered.split(";") if s.strip()
                  and not all(l.strip().startswith("--")
                              for l in s.strip().splitlines())]
    errors, applied = [], 0
    for stmt in statements:
        try:
            cur.execute(stmt)
            applied += 1
        except Exception as exc:  # noqa: BLE001
            # Grants are independent: collect all failures, do not stop at the
            # first one. A complete failure list beats a first-failure abort.
            errors.append(f"{stmt.splitlines()[0][:100]} -> {exc}")
    if errors:
        raise RuntimeError(
            f"{applied} grant(s) applied, {len(errors)} failed:\n  - "
            + "\n  - ".join(errors))
    return f"{applied} grant statement(s) applied"


DISPATCH = {
    mf.SEMANTIC_VIEW: deploy_semantic_view,
    mf.CORTEX_AGENT: deploy_cortex_agent,
}


def main() -> int:  # noqa: PLR0912, PLR0915
    ap = argparse.ArgumentParser()
    ap.add_argument("--bundle", required=True)
    ap.add_argument("--environment", required=True,
                    choices=("dev", "test", "prod"))
    ap.add_argument("--change-request", default="")
    ap.add_argument("--pipeline-run-url", default="")
    ap.add_argument("--phase-only", type=int)
    ap.add_argument("--force", action="store_true",
                    help="full reconcile: ignore change detection")
    ap.add_argument("--log-json")
    args = ap.parse_args()

    bundle = Path(args.bundle)
    lock = json.loads((bundle / "manifest.lock.json").read_text())
    cfg = config.load(args.environment,
                      bundle_version=lock["bundle_version"],
                      git_commit=lock["git_commit"])

    if cfg.policy.get("require_change_request") and not args.change_request:
        return int(bool(sys.stderr.write(
            "FATAL: --change-request is required for "
            f"{args.environment}\n")) or 1)

    manifest = mf.load(bundle / "dependencies" / "manifest.yaml")
    bundle_shas = {a["logical_name"]: a["rendered_sha256"][args.environment]
                   for a in lock["artifacts"]}
    reconcile_all = args.force or cfg.policy.get("reconcile") == "full"
    log = JsonLog(args.log_json)
    deployment_id = ledger.new_deployment_id()

    print(f"deployment {deployment_id}\n"
          f"  environment : {args.environment}\n"
          f"  bundle      : {lock['bundle_version']} ({lock['git_commit'][:9]})\n"
          f"  reconcile   : {'full' if reconcile_all else 'changed only'}\n"
          f"  change req  : {args.change_request or 'n/a'}")

    with session.connect(cfg) as conn:
        cur = conn.cursor()
        ledger.ensure_tables(cur, cfg)

        if args.phase_only == 0:
            phase_00_preconditions(cur, cfg, manifest, bundle)
            log.write(phase=0, logical_name="PRECONDITIONS",
                      action="CHECK", status="SUCCESS")
            log.close()
            return 0

        live = ledger.live_shas(cur, cfg)
        plan = mf.plan(manifest, live, bundle_shas, reconcile_all=reconcile_all)

        with ledger.advisory_lock(cur, cfg, deployment_id,
                                 args.pipeline_run_url):
            phase_00_preconditions(cur, cfg, manifest, bundle)

            for phase in cfg.phases:
                if phase in (0, 60):
                    continue
                if args.phase_only is not None and phase != args.phase_only:
                    continue
                items = [a for a in plan if a.phase == phase]
                if not items:
                    continue
                print(f"\n-- phase {phase}: {len(items)} item(s)")

                for art in items:
                    if art.action == "SKIP":
                        print(f"   SKIP    {art.logical_name} (unchanged)")
                        ledger.record(cur, cfg, deployment_id=deployment_id,
                                      artifact=art, status="SUCCESS",
                                      detail="unchanged",
                                      change_request=args.change_request,
                                      run_url=args.pipeline_run_url)
                        log.write(phase=phase, logical_name=art.logical_name,
                                  action="SKIP", status="SUCCESS")
                        continue
                    text = (bundle / "rendered" / args.environment
                            / art.rendered_path).read_text()
                    try:
                        if art.type == mf.GRANT_SCRIPT:
                            detail = run_grant_script(cur, cfg, art, text,
                                                      manifest)
                        else:
                            detail = DISPATCH[art.type](cur, cfg, art, text)
                        print(f"   DEPLOY  {art.logical_name}: {detail}")
                        ledger.record(cur, cfg, deployment_id=deployment_id,
                                      artifact=art, status="SUCCESS",
                                      detail=detail,
                                      change_request=args.change_request,
                                      run_url=args.pipeline_run_url)
                        log.write(phase=phase, logical_name=art.logical_name,
                                  action="DEPLOYED", status="SUCCESS",
                                  detail=detail)
                    except Exception as exc:  # noqa: BLE001
                        ledger.record(cur, cfg, deployment_id=deployment_id,
                                      artifact=art, status="FAILED",
                                      error=str(exc),
                                      change_request=args.change_request,
                                      run_url=args.pipeline_run_url)
                        log.write(phase=phase, logical_name=art.logical_name,
                                  action="DEPLOYED", status="FAILED",
                                  detail=str(exc))
                        log.close()
                        # HARD BARRIER. Never proceed to a later phase: an
                        # agent must not be rewired to a layer that failed.
                        sys.stderr.write(
                            f"\nFATAL phase {phase} / {art.logical_name}: "
                            f"{exc}\n"
                            f"Already-deployed artifacts remain valid "
                            f"(CREATE OR REPLACE is atomic per object).\n"
                            f"Converge with: python scripts/deploy.py "
                            f"--bundle {args.bundle} --environment "
                            f"{args.environment} --force\n"
                            f"or roll back: python scripts/rollback.py "
                            f"--environment {args.environment} "
                            f"--to-version <prev>\n")
                        return 1

    log.close()
    print("\ndeployment completed successfully")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
