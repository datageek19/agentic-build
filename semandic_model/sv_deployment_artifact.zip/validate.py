#!/usr/bin/env python3
"""Post-deployment and drift validation.

Suites:
  smoke            D01-D04, D07, D08  existence, member inventory, queries
  drift            D05, D13           structural equality vs the bundle
  grants           D06                grant matrix
  verified_queries D10                replay of curated worked examples
  golden           D09, D11, D12      NL-to-SQL accuracy (see UNRESOLVED-4)
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import yaml  # noqa: E402

from lib import config, manifest as mf, render, session  # noqa: E402

REPO = Path(__file__).resolve().parents[1]


def normalise(spec: dict) -> dict:
    """Canonical form for structural comparison (D05).

    Strips what Snowflake legitimately rewrites: key order, whitespace, and
    data_type - which can be set in YAML but is re-derived by the compiler on
    the read path.
    """
    def strip(node):
        if isinstance(node, dict):
            return {k: strip(v) for k, v in sorted(node.items())
                    if k != "data_type"}
        if isinstance(node, list):
            items = [strip(x) for x in node]
            if items and all(isinstance(x, dict) and "name" in x for x in items):
                return sorted(items, key=lambda x: str(x["name"]))
            return items
        if isinstance(node, str):
            return " ".join(node.split())
        return node
    return strip(spec)


class Results:
    def __init__(self):
        self.rows: list[dict] = []

    def add(self, suite, check, name, result, detail=""):
        self.rows.append({"suite": suite, "check": check, "name": name,
                          "result": result, "detail": detail})
        marker = {"PASS": "PASS ", "WARN": "WARN ", "FAIL": "FAIL "}[result]
        print(f"{marker} [{check}] {name}"
              + (f": {detail[:160]}" if detail else ""))

    @property
    def failures(self):
        return [r for r in self.rows if r["result"] == "FAIL"]

    @property
    def warnings(self):
        return [r for r in self.rows if r["result"] == "WARN"]

    def junit(self, path):
        suites = ET.Element("testsuites")
        ts = ET.SubElement(suites, "testsuite", name="semantic-validation",
                           tests=str(len(self.rows)),
                           failures=str(len(self.failures)))
        for r in self.rows:
            tc = ET.SubElement(ts, "testcase",
                               classname=f"{r['suite']}.{r['check']}",
                               name=r["name"])
            if r["result"] == "FAIL":
                ET.SubElement(tc, "failure", message=r["detail"][:500])
            elif r["result"] == "WARN":
                ET.SubElement(tc, "skipped", message=r["detail"][:500])
        ET.ElementTree(suites).write(path, encoding="utf-8",
                                     xml_declaration=True)


def suite_smoke(cur, cfg, manifest, res):
    cur.execute(f"SHOW SEMANTIC VIEWS IN SCHEMA {cfg.schema_bi_fqn}")
    rows = cur.fetchall()
    cols = [d[0].lower() for d in cur.description]
    live = {r[cols.index("name")] for r in rows}

    for name in manifest.semantic_view_names:
        if name in live:
            res.add("smoke", "D01", name, "PASS")
        else:
            res.add("smoke", "D01", name, "FAIL", "semantic view not found")
            continue

        fqn = f"{cfg.schema_bi_fqn}.{name}"
        for check, cmd in (("D02", "SEMANTIC DIMENSIONS"),
                           ("D03", "SEMANTIC FACTS"),
                           ("D04", "SEMANTIC METRICS")):
            try:
                cur.execute(f"SHOW {cmd} IN SEMANTIC VIEW {fqn}")
                n = len(cur.fetchall())
                res.add("smoke", check, f"{name} ({cmd.lower()})",
                        "PASS" if n or check == "D03" else "WARN", f"{n} member(s)")
            except Exception as exc:  # noqa: BLE001
                res.add("smoke", check, f"{name} ({cmd.lower()})", "FAIL",
                        str(exc))

        try:
            cur.execute(f"DESCRIBE SEMANTIC VIEW {fqn}")
            cur.fetchall()
            res.add("smoke", "D07", f"{name} describe", "PASS")
        except Exception as exc:  # noqa: BLE001
            res.add("smoke", "D07", f"{name} describe", "FAIL", str(exc))


def suite_drift(cur, cfg, manifest, res, bundle):
    for art in manifest.of_type(mf.SEMANTIC_VIEW):
        fqn = f"{cfg.schema_bi_fqn}.{art.logical_name}"
        try:
            cur.execute("SELECT SYSTEM$READ_YAML_FROM_SEMANTIC_VIEW(%s)", (fqn,))
            live = normalise(yaml.safe_load(cur.fetchone()[0]))
        except Exception as exc:  # noqa: BLE001
            res.add("drift", "D05", art.logical_name, "FAIL",
                    f"could not export live definition: {exc}")
            continue
        if bundle:
            want_text = (Path(bundle) / "rendered" / cfg.environment
                         / art.source).read_text()
        else:
            want_text = render.render((REPO / art.source).read_text(),
                                      dict(cfg.tokens), path=art.source)
        want = normalise(yaml.safe_load(want_text))
        if live == want:
            res.add("drift", "D05", art.logical_name, "PASS")
        else:
            diffs = sorted(set(want) ^ set(live)) or ["nested difference"]
            res.add("drift", "D05", art.logical_name, "FAIL",
                    f"live definition differs from bundle; top-level keys "
                    f"differing: {diffs}")


def suite_grants(cur, cfg, manifest, res):
    expected = set(cfg.consumer_roles)
    for name in manifest.semantic_view_names:
        fqn = f"{cfg.schema_bi_fqn}.{name}"
        try:
            cur.execute(f"SHOW GRANTS ON SEMANTIC VIEW {fqn}")
            rows = cur.fetchall()
            cols = [d[0].lower() for d in cur.description]
        except Exception as exc:  # noqa: BLE001
            res.add("grants", "D06", name, "FAIL", str(exc))
            continue
        i_priv, i_grantee = cols.index("privilege"), cols.index("grantee_name")
        granted = {r[i_grantee] for r in rows if r[i_priv] == "SELECT"}
        missing = expected - granted
        unexpected = granted - expected
        if missing:
            res.add("grants", "D06", f"{name} missing", "FAIL",
                    f"consumer roles without SELECT: {sorted(missing)}")
        else:
            res.add("grants", "D06", f"{name} coverage", "PASS")
        if unexpected:
            # Blocking in PROD: grant copying on replace makes an out-of-band
            # grant propagate forward through every future deployment.
            level = "FAIL" if cfg.environment == "prod" else "WARN"
            res.add("grants", "D06", f"{name} unexpected", level,
                    f"unexpected SELECT grantees: {sorted(unexpected)}")


def suite_verified_queries(cur, cfg, manifest, res, bundle):
    for art in manifest.of_type(mf.SEMANTIC_VIEW):
        if bundle:
            text = (Path(bundle) / "rendered" / cfg.environment
                    / art.source).read_text()
        else:
            text = render.render((REPO / art.source).read_text(),
                                 dict(cfg.tokens), path=art.source)
        for vq in yaml.safe_load(text).get("verified_queries", []) or []:
            label = f"{art.logical_name}/{vq['name']}"
            try:
                cur.execute(vq["sql"])
                rows = cur.fetchmany(5)
                if rows:
                    res.add("verified_queries", "D10", label, "PASS",
                            f"{len(rows)}+ row(s)")
                else:
                    res.add("verified_queries", "D10", label, "FAIL",
                            "returned zero rows; Cortex Analyst treats "
                            "verified queries as worked examples")
            except Exception as exc:  # noqa: BLE001
                res.add("verified_queries", "D10", label, "FAIL", str(exc))


def suite_golden(cur, cfg, manifest, res):
    """D09/D11/D12.

    UNRESOLVED-4: the programmatic NL-to-SQL invocation path is not confirmed
    in this package, so no call is written that cannot be stood behind. The
    privilege half of D09 IS implemented and blocking; the live round trip is
    reported as WARN until the invocation is verified in DEV.
    """
    for role in cfg.consumer_roles:
        try:
            cur.execute("SHOW GRANTS TO ROLE IDENTIFIER(%s)", (role,))
            rows = [str(r) for r in cur.fetchall()]
        except Exception as exc:  # noqa: BLE001
            res.add("golden", "D09", f"{role} cortex role", "FAIL", str(exc))
            continue
        blob = " ".join(rows).upper()
        if "CORTEX_ANALYST_USER" in blob or "CORTEX_USER" in blob:
            res.add("golden", "D09", f"{role} cortex role", "PASS")
        else:
            res.add("golden", "D09", f"{role} cortex role", "FAIL",
                    "role holds neither SNOWFLAKE.CORTEX_ANALYST_USER nor "
                    "SNOWFLAKE.CORTEX_USER; Cortex Analyst access will fail")

    gdir = REPO / "tests" / "golden"
    cases = 0
    for gf in sorted(gdir.glob("*.golden.yaml")):
        for case in yaml.safe_load(gf.read_text()).get("cases", []) or []:
            cases += 1
            res.add("golden", "D11", case["id"], "WARN",
                    "NL-to-SQL invocation not yet wired; see UNRESOLVED-4")
    if cases:
        res.add("golden", "D11", "accuracy gate", "WARN",
                f"{cases} golden case(s) defined but not executed")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--environment", required=True,
                    choices=("dev", "test", "prod"))
    ap.add_argument("--suite", default="smoke",
                    help="comma-separated: smoke,drift,grants,"
                         "verified_queries,golden")
    ap.add_argument("--bundle")
    ap.add_argument("--blocking", action="store_true")
    ap.add_argument("--junit")
    ap.add_argument("--report")
    args = ap.parse_args()

    version = commit = "unknown"
    if args.bundle:
        lock = json.loads((Path(args.bundle) / "manifest.lock.json").read_text())
        version, commit = lock["bundle_version"], lock["git_commit"]

    cfg = config.load(args.environment, bundle_version=version, git_commit=commit)
    manifest_path = ((Path(args.bundle) / "dependencies" / "manifest.yaml")
                     if args.bundle else mf.MANIFEST_PATH)
    manifest = mf.load(manifest_path)
    suites = [s.strip() for s in args.suite.split(",") if s.strip()]
    res = Results()

    with session.connect(
        cfg,
        role=cfg.validate_connection.get("role"),
        user=cfg.validate_connection.get("user"),
    ) as conn:
        cur = conn.cursor()
        if "smoke" in suites:
            suite_smoke(cur, cfg, manifest, res)
        if "drift" in suites:
            suite_drift(cur, cfg, manifest, res, args.bundle)
        if "grants" in suites:
            suite_grants(cur, cfg, manifest, res)
        if "verified_queries" in suites:
            suite_verified_queries(cur, cfg, manifest, res, args.bundle)
        if "golden" in suites:
            suite_golden(cur, cfg, manifest, res)

    if args.junit:
        res.junit(args.junit)
    if args.report:
        Path(args.report).write_text(json.dumps(
            {"environment": args.environment, "bundle_version": version,
             "suites": suites, "results": res.rows,
             "failed": len(res.failures), "warned": len(res.warnings)},
            indent=2))

    print(f"\n{len(res.rows)} check(s): {len(res.failures)} failed, "
          f"{len(res.warnings)} warning(s)")

    # Warning budget: prevents warning-blindness where 200 warnings mean
    # nobody reads any.
    budget = 10 * max(1, len(manifest.semantic_view_names))
    if len(res.warnings) > budget:
        print(f"FAIL: warning budget exceeded ({len(res.warnings)} > {budget})",
              file=sys.stderr)
        return 1
    if res.failures and args.blocking:
        return 1
    if res.failures:
        print("failures present but --blocking not set; not failing the stage")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
