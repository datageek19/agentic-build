#!/usr/bin/env python3
"""Capture pre-deploy state of every managed semantic view.

Semantic views have no Time Travel or UNDROP, so this snapshot is the only
recovery path when the rollback target predates Git history, or when the
environment held Snowsight edits that were never committed.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from lib import config, manifest as mf, session  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--environment", required=True,
                    choices=("dev", "test", "prod"))
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    cfg = config.load(args.environment)
    manifest = mf.load()
    stamp = f"{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}"
    out = Path(args.out) / f"{args.environment}-{stamp}"
    out.mkdir(parents=True, exist_ok=True)
    index = []

    with session.connect(
        cfg,
        role=cfg.validate_connection.get("role"),
        user=cfg.validate_connection.get("user"),
    ) as conn:
        cur = conn.cursor()
        for art in manifest.of_type(mf.SEMANTIC_VIEW):
            fqn = f"{cfg.schema_bi_fqn}.{art.logical_name}"
            entry = {"logical_name": art.logical_name, "target_fqn": fqn}
            try:
                cur.execute("SELECT SYSTEM$READ_YAML_FROM_SEMANTIC_VIEW(%s)",
                            (fqn,))
                (out / f"{art.logical_name}.sv.yaml").write_text(cur.fetchone()[0])
                cur.execute("SELECT GET_DDL('SEMANTIC_VIEW', %s)", (fqn,))
                (out / f"{art.logical_name}.sql").write_text(cur.fetchone()[0])
                entry["captured"] = True
                print(f"captured {art.logical_name}")
            except Exception as exc:  # noqa: BLE001
                entry["captured"] = False
                entry["error"] = str(exc)
                print(f"not captured {art.logical_name}: {exc}")
            index.append(entry)

    (out / "index.json").write_text(json.dumps({
        "environment": args.environment, "captured_at": stamp,
        "artifacts": index}, indent=2))
    print(f"snapshot -> {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
