-- Bootstrap 01: least-privilege role hierarchy and WIF service identities.
-- Run by SECURITYADMIN. Idempotent.
--
-- The pipeline is NEVER granted ACCOUNTADMIN, SECURITYADMIN or SYSADMIN.
-- R_SEMANTIC_DEPLOY_<ENV> is a leaf role holding CREATE SEMANTIC VIEW on
-- exactly one schema.
--
-- Object creation is separated from grant administration: DEPLOY creates
-- objects but cannot grant on them; GRANTOR grants but cannot create. This
-- prevents a compromised CI run from creating a view over any readable table
-- and granting itself access to the result.

USE ROLE SECURITYADMIN;

-- ---------------------------------------------------------------- roles
CREATE ROLE IF NOT EXISTS R_SEMANTIC_ADMIN_<% env %>
  COMMENT = 'Owns semantic-layer containers. Human-operated.';
CREATE ROLE IF NOT EXISTS R_SEMANTIC_DEPLOY_<% env %>
  COMMENT = 'CI write identity. CREATE SEMANTIC VIEW on one schema only.';
CREATE ROLE IF NOT EXISTS R_SEMANTIC_VALIDATE_<% env %>
  COMMENT = 'CI read identity. PR verify_only, post-deploy checks, drift.';
CREATE ROLE IF NOT EXISTS R_SEMANTIC_GRANTOR_<% env %>
  COMMENT = 'Grant administration only. Cannot create objects.';
CREATE ROLE IF NOT EXISTS R_SEMANTIC_BREAKGLASS_<% env %>
  COMMENT = 'Break-glass BG-1. Granted to a named human, time-boxed only.';

-- ------------------------------------------------- service users (WIF only)
-- Azure DevOps: issuer is the Azure DevOps token service for your tenant;
-- subject is the service-connection identifier.
-- GitHub Actions: issuer is GitHub's OIDC provider; subject is scoped to a
-- GitHub ENVIRONMENT, so a job that does not declare that environment cannot
-- obtain an acceptable token. The human approval then gates the credential
-- itself, not merely the deployment step.

CREATE USER IF NOT EXISTS SVC_SEMANTIC_DEPLOY_<% env %>
  TYPE = SERVICE
  WORKLOAD_IDENTITY = (
    TYPE = OIDC
    ISSUER  = 'https://vstoken.dev.azure.com/<% tenant_id %>'
    SUBJECT = 'sc://<% ado_org %>/<% ado_project %>/<% svc_conn %>'
    OIDC_AUDIENCE_LIST = ('api://AzureADTokenExchange')
  )
  DEFAULT_ROLE      = R_SEMANTIC_DEPLOY_<% env %>
  DEFAULT_WAREHOUSE = <% warehouse %>
  COMMENT = 'Semantic layer CI deploy identity. WIF only. No password, no key.';

-- GitHub Actions variant. Apply ONE of the two; do not create both against
-- the same user object.
-- ALTER USER SVC_SEMANTIC_DEPLOY_<% env %> SET WORKLOAD_IDENTITY = (
--   TYPE = OIDC
--   ISSUER  = 'https://token.actions.githubusercontent.com'
--   SUBJECT = 'repo:<% gh_org %>/<% gh_repo %>:environment:sf-<% env %>'
-- );

CREATE USER IF NOT EXISTS SVC_SEMANTIC_VALIDATE_<% env %>
  TYPE = SERVICE
  WORKLOAD_IDENTITY = (
    TYPE = OIDC
    ISSUER  = 'https://vstoken.dev.azure.com/<% tenant_id %>'
    SUBJECT = 'sc://<% ado_org %>/<% ado_project %>/<% svc_conn %>'
    OIDC_AUDIENCE_LIST = ('api://AzureADTokenExchange')
  )
  DEFAULT_ROLE      = R_SEMANTIC_VALIDATE_<% env %>
  DEFAULT_WAREHOUSE = <% warehouse %>
  COMMENT = 'Semantic layer CI read identity. WIF only.';

CREATE USER IF NOT EXISTS SVC_SEMANTIC_GRANTOR_<% env %>
  TYPE = SERVICE
  WORKLOAD_IDENTITY = (
    TYPE = OIDC
    ISSUER  = 'https://vstoken.dev.azure.com/<% tenant_id %>'
    SUBJECT = 'sc://<% ado_org %>/<% ado_project %>/<% svc_conn %>'
    OIDC_AUDIENCE_LIST = ('api://AzureADTokenExchange')
  )
  DEFAULT_ROLE      = R_SEMANTIC_GRANTOR_<% env %>
  DEFAULT_WAREHOUSE = <% warehouse %>
  COMMENT = 'Semantic layer grant-administration identity. WIF only.';

GRANT ROLE R_SEMANTIC_DEPLOY_<% env %>   TO USER SVC_SEMANTIC_DEPLOY_<% env %>;
GRANT ROLE R_SEMANTIC_VALIDATE_<% env %> TO USER SVC_SEMANTIC_DEPLOY_<% env %>;
GRANT ROLE R_SEMANTIC_VALIDATE_<% env %> TO USER SVC_SEMANTIC_VALIDATE_<% env %>;
GRANT ROLE R_SEMANTIC_GRANTOR_<% env %>  TO USER SVC_SEMANTIC_GRANTOR_<% env %>;

-- Container-scoped grant delegation. Avoids account-level SECURITYADMIN.
-- NOTE: container-level MANAGE GRANTS cannot transfer object ownership;
-- ownership transfer always remains a SECURITYADMIN operation.
GRANT MANAGE GRANTS ON SCHEMA <% target_db %>.<% target_schema %>
  TO ROLE R_SEMANTIC_GRANTOR_<% env %>;
GRANT MANAGE GRANTS ON SCHEMA <% exp_db %>.<% exp_schema %>
  TO ROLE R_SEMANTIC_GRANTOR_<% env %>;

-- Restrict every service user to the CI runner egress range.
-- PLACEHOLDER: create NP_CI_EGRESS first; see docs/PLACEHOLDERS.md.
-- ALTER USER SVC_SEMANTIC_DEPLOY_<% env %>   SET NETWORK_POLICY = NP_CI_EGRESS;
-- ALTER USER SVC_SEMANTIC_VALIDATE_<% env %> SET NETWORK_POLICY = NP_CI_EGRESS;
-- ALTER USER SVC_SEMANTIC_GRANTOR_<% env %>  SET NETWORK_POLICY = NP_CI_EGRESS;
