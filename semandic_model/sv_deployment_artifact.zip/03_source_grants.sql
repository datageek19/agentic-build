-- Bootstrap 03: base-table read access for the deploy role.
--
-- MUST be executed by the OWNER OF THE SOURCE DATABASE, not by this
-- project's admin role.
--
-- Semantic views use owner's rights: a consumer holding SELECT on the view
-- does not need access to the base tables. Therefore the base-table grants
-- below define the MAXIMUM data surface any consumer can reach through the
-- semantic layer. Adding a table here widens that ceiling for every consumer
-- of every view in the schema - treat changes as a security review.
--
-- Grants are ENUMERATED per table. GRANT SELECT ON FUTURE TABLES in a source
-- schema would silently widen the ceiling every time the source team lands a
-- new table.

USE ROLE <% source_owner_role %>;

GRANT USAGE ON DATABASE <% land_db %> TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT USAGE ON SCHEMA <% land_db %>.<% land_schema %>
  TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT USAGE ON DATABASE <% land_db %> TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
GRANT USAGE ON SCHEMA <% land_db %>.<% land_schema %>
  TO ROLE R_SEMANTIC_VALIDATE_<% env %>;

-- Exactly the tables in dependencies/source_contracts.yaml: land_core.
-- Static check S09 and precondition P02/P03 keep this list in step.
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_PARTICIPATION      TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_AGMT_HDR           TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_COP_WI             TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_RELATED_WELL_AGMT  TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_BA_NAME            TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_BA_ADDRESS         TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_BA_ADDR_USAGES     TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_PIP_TYPES              TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_PIP_TYPE_CATG          TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_COP_RPA_DSM_PLSE_JVA   TO ROLE R_SEMANTIC_DEPLOY_<% env %>;

-- Same list to the validate role, for precondition and drift checks.
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_PARTICIPATION      TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_AGMT_HDR           TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_COP_WI             TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_RELATED_WELL_AGMT  TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
