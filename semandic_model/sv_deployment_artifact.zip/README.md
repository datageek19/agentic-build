# Snowflake Semantic Layer — CI/CD

Version-controlled deployment of Snowflake **semantic views** and **Cortex
Agents** across DEV → TEST → PROD, on Azure DevOps and GitHub Actions.

## Mechanism

Source of truth is the tokenised `.sv.yaml` model. Deployment calls
`SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML` through the Snowflake Python
connector, driven by a repository-owned script. `verify_only => TRUE` is the
pull-request gate. Everything is GA; no production path depends on a preview
feature.

All behaviour lives in `scripts/`. `azure-pipelines/` and `.github/workflows/`
are thin, functionally equivalent wrappers that supply credentials, approvals
and concurrency only.

## Layout

| Path | Purpose |
|---|---|
| `semantic_views/` | **Source of truth.** Tokenised, environment-neutral |
| `agents/` | Cortex Agent specifications |
| `dependencies/` | Deployment manifest and source data contracts |
| `configuration/` | Token registry and per-environment variable bindings |
| `grants/` | Phase 30/50 grant templates |
| `bootstrap/` | One-time, human-run role and container setup |
| `scripts/` | All deployment logic |
| `tests/` | Static, precondition and post-deployment validation |
| `generated/` | **CI-written. Editing has no effect** |
| `docs/` | Placeholder register, runbook, package document |

## Quick start

```bash
pip install -r scripts/requirements.txt

# T0 static gate — offline, no credentials
python -m pytest tests/policy -v

# Render all three environments without secrets
python scripts/build.py --all-environments --token-shape-only \
  --dry-run --out /tmp/render-check

# With environment variables set (see docs/PLACEHOLDERS.md)
python scripts/verify.py --environment dev --report verify.json
python scripts/build.py --all-environments --version 1.0.0 \
  --commit "$(git rev-parse HEAD)" --out build/bundle
python scripts/deploy.py --bundle build/bundle --environment dev
python scripts/validate.py --environment dev --suite smoke,drift,grants
```

## Load-bearing strings

Renaming any of these breaks authentication, and the failure looks like a
configuration bug rather than a security control working correctly:

1. GitHub repository name and owner
2. GitHub environment names (`sf-dev`, `sf-test`, `sf-prod`, `sf-dev-verify`)
3. Azure DevOps organisation and project name
4. Azure DevOps service connection names

They appear in the OIDC subject claim of each Snowflake service user. Treat a
rename as a credential rotation.

## Non-negotiables

- The pipeline never holds `ACCOUNTADMIN`, `SECURITYADMIN` or `SYSADMIN`.
- Humans hold `CREATE SEMANTIC VIEW` in DEV only. Snowsight edits in TEST or
  PROD are silently destroyed by the next deployment.
- `cancel-in-progress` is `false` on every deployment.
- PROD always reconciles fully.
- After any rollback, open a revert PR so Git and the environment reconverge.

See `docs/IMPLEMENTATION_PACKAGE.md` for the full design and
`docs/RUNBOOK.md` for operations.
