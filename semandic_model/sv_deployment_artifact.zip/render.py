"""Token substitution over RAW TEXT.

Deliberately NOT a YAML round trip. Parsing with PyYAML and re-dumping would
reorder keys, normalise quoting, reflow synonym lists and strip comments,
producing rendered files whose diff against the source is unreadable - which
destroys the reviewability that motivated choosing YAML as the source format.

We substitute over bytes, then parse ONCE only to validate.
"""
from __future__ import annotations

import re

import yaml

TOKEN = re.compile(r"\$\{([a-z][a-z0-9_]*)\}")


class RenderError(RuntimeError):
    pass


def used_tokens(text: str) -> set[str]:
    return {m.group(1) for m in TOKEN.finditer(text)}


def render(text: str, values: dict, path: str = "<text>",
           validate_yaml: bool = True) -> str:
    missing = used_tokens(text) - {k for k, v in values.items() if v is not None}
    if missing:
        raise RenderError(f"{path}: unresolved tokens {sorted(missing)}")

    out = TOKEN.sub(lambda m: str(values[m.group(1)]), text)

    if TOKEN.search(out):
        raise RenderError(f"{path}: a token expanded into another token")

    if validate_yaml:
        try:
            parsed = yaml.safe_load(out)
        except yaml.YAMLError as exc:
            raise RenderError(f"{path}: rendered output is not valid YAML: {exc}")
        if not isinstance(parsed, dict) or "name" not in parsed:
            raise RenderError(f"{path}: rendered YAML has no top-level 'name'")
    return out
