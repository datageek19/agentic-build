#!/usr/bin/env python3
"""Pre-merge verification via SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML.

verify_only=TRUE validates the YAML, resolves base-table references and
validates column identifiers WITHOUT creating anything. This is the real
pull-request gate. It runs under the read-only validate role so a pull
request from any branch can never hold write privileges.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from lib import config, manifest as mf, render, session  # noqa: E402

REPO = Path(__file__).resolve().parents[1]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--environment", required=True)
    ap.add_argument("--report", default="verify-report.json")
    ap.add_argument("--bundle", help="verify pre-rendered bundle instead of source")
    args = ap.parse_args()

    cfg = config.load(args.environment)
    manifest = mf.load()
    results, failed = [], 0

    with session.connect(
        cfg,
        role=cfg.validate_connection.get("role"),
        user=cfg.validate_connection.get("user"),
    ) as conn:
        cur = conn.cursor()
        for art in manifest.of_type(mf.SEMANTIC_VIEW):
            if args.bundle:
                text = (Path(args.bundle) / "rendered" / args.environment
                        / art.source).read_text()
            else:
                text = render.render((REPO / art.source).read_text(),
                                     dict(cfg.tokens), path=art.source)
            try:
                cur.execute(
                    "CALL SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML(%s, %s, %s, %s)",
                    (cfg.schema_bi_fqn, text, True, False),
                )
                msg = cur.fetchone()[0]
                results.append({"logical_name": art.logical_name,
                                "result": "PASS", "detail": msg})
                print(f"PASS  {art.logical_name}: {msg}")
            except Exception as exc:  # noqa: BLE001
                failed += 1
                results.append({"logical_name": art.logical_name,
                                "result": "FAIL", "detail": str(exc)})
                print(f"FAIL  {art.logical_name}: {exc}", file=sys.stderr)

    Path(args.report).write_text(json.dumps(
        {"environment": args.environment, "checked": len(results),
         "failed": failed, "results": results}, indent=2))
    print(f"\nverify_only: {len(results) - failed}/{len(results)} passed")
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())
