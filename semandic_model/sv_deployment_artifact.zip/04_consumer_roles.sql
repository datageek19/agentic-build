-- Bootstrap 04: consumer roles and the Cortex database role.
-- Run by SECURITYADMIN (granting a Snowflake database role requires it, so
-- this cannot live in the per-deployment Phase 30 script).

USE ROLE SECURITYADMIN;

CREATE ROLE IF NOT EXISTS R_SEMANTIC_CONSUMER_LAND_<% env %>
  COMMENT = 'Land domain semantic layer consumers (Cortex Analyst, agent, BI).';

-- CORTEX_ANALYST_USER, not CORTEX_USER: consumers of this semantic layer have
-- no need for the full Covered AI feature surface.
GRANT DATABASE ROLE SNOWFLAKE.CORTEX_ANALYST_USER
  TO ROLE R_SEMANTIC_CONSUMER_LAND_<% env %>;

GRANT ROLE R_SEMANTIC_CONSUMER_LAND_<% env %> TO ROLE <% consumer_parent_role %>;

-- ---------------------------------------------------------------------------
-- UNRESOLVED-3: Cortex Agents require the role EXECUTING queries to hold
-- SELECT on BOTH the semantic view AND its underlying tables. Owner's rights
-- covers direct semantic-view querying, but NOT the agent path.
--
-- Three options; C is recommended. Decide with the source-data owner BEFORE
-- the first PROD agent deployment.
--
-- A) Base-table SELECT to consumers. Agent works for all users, but consumers
--    can query raw tables directly, bypassing the semantic layer.
-- B) Service-account agent. Consumers never touch raw tables, but Snowflake
--    RBAC no longer differentiates users, so row access policies keyed on
--    CURRENT_USER() stop working - exactly where the business-associate PII
--    lives.
-- C) RECOMMENDED. Base-table SELECT to consumers, WITH row access and masking
--    policies applied at the source. Preserves per-user enforcement and
--    enables the agent. Depends on the source team owning the policies.
--
-- Option C grants (execute as the source database owner):
-- GRANT SELECT ON TABLE <% land_db %>.<% land_schema %>.QUORUM_QLREPORT_QDV_PARTICIPATION
--   TO ROLE R_SEMANTIC_CONSUMER_LAND_<% env %>;
-- ... enumerated per contracted table.
