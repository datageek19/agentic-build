"""Deployment manifest parsing, validation and plan computation."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path

import yaml

REPO = Path(__file__).resolve().parents[2]
MANIFEST_PATH = REPO / "dependencies" / "manifest.yaml"
CONTRACTS_PATH = REPO / "dependencies" / "source_contracts.yaml"

SEMANTIC_VIEW = "semantic_view"
CORTEX_AGENT = "cortex_agent"
GRANT_SCRIPT = "grant_script"


class ManifestError(RuntimeError):
    pass


@dataclass
class Artifact:
    logical_name: str
    type: str
    source: str
    phase: int
    order: int
    target: dict | None
    depends_on: list[str]
    source_contract: str | None
    action: str = "DEPLOY"
    rendered_sha256: str | None = None

    @property
    def rendered_path(self) -> str:
        return self.source


@dataclass
class Manifest:
    artifacts: list[Artifact]

    def by_source(self, source: str) -> Artifact | None:
        norm = source.replace("\\", "/")
        return next((a for a in self.artifacts if a.source == norm), None)

    def by_name(self, logical_name: str) -> Artifact | None:
        return next((a for a in self.artifacts
                     if a.logical_name == logical_name), None)

    def of_type(self, type_: str) -> list[Artifact]:
        return [a for a in self.artifacts if a.type == type_]

    @property
    def semantic_view_names(self) -> list[str]:
        return [a.logical_name for a in self.of_type(SEMANTIC_VIEW)]

    @property
    def cortex_agent_names(self) -> list[str]:
        return [a.logical_name for a in self.of_type(CORTEX_AGENT)]


def load(path: Path | str = MANIFEST_PATH) -> Manifest:
    raw = yaml.safe_load(Path(path).read_text())
    artifacts = [
        Artifact(
            logical_name=a["logical_name"],
            type=a["type"],
            source=a["source"],
            phase=int(a["phase"]),
            order=int(a["order"]),
            target=a.get("target"),
            depends_on=a.get("depends_on") or [],
            source_contract=a.get("source_contract"),
        )
        for a in raw["artifacts"]
    ]
    validate(artifacts)
    return Manifest(artifacts=artifacts)


def load_contracts(path: Path | str = CONTRACTS_PATH) -> dict:
    return yaml.safe_load(Path(path).read_text())


def validate(artifacts: list[Artifact]) -> None:
    """S03 + S08. Raises on any structural defect."""
    names = [a.logical_name for a in artifacts]
    dupe_names = {n for n in names if names.count(n) > 1}
    if dupe_names:
        raise ManifestError(f"duplicate logical_name: {sorted(dupe_names)}")

    sources = [a.source for a in artifacts]
    dupe_src = {s for s in sources if sources.count(s) > 1}
    if dupe_src:
        raise ManifestError(f"duplicate source: {sorted(dupe_src)}")

    known = set(names)
    for a in artifacts:
        for dep in a.depends_on:
            if dep not in known:
                raise ManifestError(
                    f"{a.logical_name} depends on unknown artifact '{dep}'")
            dep_art = next(x for x in artifacts if x.logical_name == dep)
            if dep_art.phase > a.phase:
                raise ManifestError(
                    f"{a.logical_name} (phase {a.phase}) depends on "
                    f"{dep} (phase {dep_art.phase}) - forward dependency "
                    f"across a phase boundary is not allowed")

    _assert_acyclic(artifacts)


def _assert_acyclic(artifacts: list[Artifact]) -> None:
    graph = {a.logical_name: list(a.depends_on) for a in artifacts}
    state: dict[str, int] = {}

    def visit(node: str, stack: list[str]) -> None:
        if state.get(node) == 2:
            return
        if state.get(node) == 1:
            raise ManifestError(
                f"dependency cycle: {' -> '.join(stack + [node])}")
        state[node] = 1
        for dep in graph.get(node, []):
            visit(dep, stack + [node])
        state[node] = 2

    for name in graph:
        visit(name, [])


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def plan(manifest: Manifest, live_shas: dict[str, str],
         bundle_shas: dict[str, str], *, reconcile_all: bool) -> list[Artifact]:
    """Change detection on the RENDERED artifact sha, keyed per environment.

    Hashing the source file would miss a change to an environment config that
    repoints every base_table without touching any model file. Comparing the
    rendered sha catches that correctly.
    """
    out: list[Artifact] = []
    for a in manifest.artifacts:
        a.rendered_sha256 = bundle_shas.get(a.logical_name)
        if reconcile_all or a.type == GRANT_SCRIPT:
            a.action = "DEPLOY"
        elif a.rendered_sha256 and live_shas.get(a.logical_name) == a.rendered_sha256:
            a.action = "SKIP"
        else:
            a.action = "DEPLOY"
        out.append(a)
    return sorted(out, key=lambda x: (x.phase, x.order))
