#!/usr/bin/env python3
"""Roll forward to a prior known-good bundle, or restore from a snapshot.

There is NO transactional rollback for a multi-object deployment: DDL in
Snowflake auto-commits and no BEGIN/ROLLBACK spans several CALL statements.
CREATE OR REPLACE is atomic PER OBJECT only.

Primary pattern: redeploy the previous bundle with a full reconcile.
Break-glass pattern: restore from the pre-deploy snapshot.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from lib import config, ledger, session  # noqa: E402

RECONVERGE = (
    "\nREQUIRED FOLLOW-UP: open a revert PR against main so that Git and this\n"
    "environment reconverge. Until that merges, the next unrelated release\n"
    "will redeploy the reverted change. This is the step that turns one\n"
    "rollback into a repeat incident.\n")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--environment", required=True,
                    choices=("dev", "test", "prod"))
    ap.add_argument("--to-version", help="prior bundle semver, e.g. 1.3.2")
    ap.add_argument("--bundle", help="path to the prior bundle directory")
    ap.add_argument("--from-snapshot", help="break-glass: snapshot directory")
    ap.add_argument("--reason", required=True)
    ap.add_argument("--change-request", default="")
    ap.add_argument("--pipeline-run-url", default="")
    args = ap.parse_args()

    if not args.to_version and not args.from_snapshot:
        sys.stderr.write("specify --to-version or --from-snapshot\n")
        return 2

    cfg = config.load(args.environment)

    with session.connect(cfg) as conn:
        cur = conn.cursor()
        ledger.ensure_tables(cur, cfg)
        print(f"current state of {args.environment}:")
        for name, bundle_v, commit, when, status in ledger.current_state(cur, cfg):
            print(f"  {name:40} {bundle_v:14} {str(commit)[:9]:10} "
                  f"{status:9} {when}")

    if args.to_version:
        bundle = args.bundle or f"artifacts/semantic-layer-{args.to_version}"
        if not Path(bundle, "manifest.lock.json").exists():
            sys.stderr.write(
                f"\nFATAL: no bundle at {bundle}. Download the build artifact "
                f"for {args.to_version} first (400-day retention), e.g.\n"
                f"  gh run download <build-run-id> -n "
                f"semantic-layer-{args.to_version}-<sha7>\n")
            return 1
        print(f"\nredeploying bundle {args.to_version} to {args.environment} "
              f"with a full reconcile")
        rc = subprocess.call([
            sys.executable, str(Path(__file__).with_name("deploy.py")),
            "--bundle", bundle,
            "--environment", args.environment,
            "--change-request", args.change_request,
            "--pipeline-run-url", args.pipeline_run_url,
            "--force",
        ])
        if rc:
            sys.stderr.write("\nrollback deployment FAILED; environment may be "
                             "in a mixed state. Re-run with --force.\n")
            return rc
        _record(cfg, mode="BUNDLE", reason=args.reason,
                target=args.to_version, cr=args.change_request,
                url=args.pipeline_run_url)
        print(RECONVERGE)
        return 0

    # Break-glass snapshot restore.
    snap = Path(args.from_snapshot)
    index = json.loads((snap / "index.json").read_text())
    print(f"\nrestoring {args.environment} from snapshot "
          f"{index['captured_at']} (break-glass)")
    with session.connect(cfg) as conn:
        cur = conn.cursor()
        for entry in index["artifacts"]:
            if not entry.get("captured"):
                print(f"  skip {entry['logical_name']} (not in snapshot)")
                continue
            text = (snap / f"{entry['logical_name']}.sv.yaml").read_text()
            cur.execute(
                "CALL SYSTEM$CREATE_SEMANTIC_VIEW_FROM_YAML(%s, %s, %s, %s)",
                (cfg.schema_bi_fqn, text, False, False))
            print(f"  restored {entry['logical_name']}: {cur.fetchone()[0]}")
    _record(cfg, mode="SNAPSHOT", reason=args.reason,
            target=index["captured_at"], cr=args.change_request,
            url=args.pipeline_run_url)
    print("\nREQUIRED FOLLOW-UP: commit the restored YAML to Git, or the "
          "nightly drift detector will flag this environment indefinitely.")
    return 0


def _record(cfg, *, mode, reason, target, cr, url):
    class _A:
        logical_name = "ROLLBACK"
        type = "rollback"
        target = None
        action = "ROLLED_BACK"
        rendered_sha256 = None
    with session.connect(cfg) as conn:
        cur = conn.cursor()
        ledger.record(cur, cfg, deployment_id=ledger.new_deployment_id(),
                      artifact=_A(), status="SUCCESS",
                      detail=f"mode={mode} target={target} reason={reason}",
                      change_request=cr, run_url=url)


if __name__ == "__main__":
    raise SystemExit(main())
