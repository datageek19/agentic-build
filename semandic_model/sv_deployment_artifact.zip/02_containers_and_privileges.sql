-- Bootstrap 02: containers, warehouse, ledger tables, and the minimum
-- privileges the pipeline needs. Run by SYSADMIN (or R_SEMANTIC_ADMIN).
-- Idempotent.

USE ROLE SYSADMIN;

CREATE DATABASE IF NOT EXISTS <% target_db %>;
CREATE DATABASE IF NOT EXISTS <% exp_db %>;

-- MANAGED ACCESS: only the schema owner may grant on objects inside it, so
-- R_SEMANTIC_DEPLOY owns the views but is structurally unable to grant on
-- them. This enforces the DEPLOY/GRANTOR split in Snowflake rather than by
-- role hygiene. Verify Phase 30 end-to-end in DEV before enabling in PROD.
CREATE SCHEMA IF NOT EXISTS <% target_db %>.<% target_schema %> WITH MANAGED ACCESS;
CREATE SCHEMA IF NOT EXISTS <% exp_db %>.<% exp_schema %>       WITH MANAGED ACCESS;

CREATE WAREHOUSE IF NOT EXISTS <% warehouse %>
  WAREHOUSE_SIZE = XSMALL
  AUTO_SUSPEND = 60
  AUTO_RESUME = TRUE
  INITIALLY_SUSPENDED = TRUE
  COMMENT = 'Semantic layer deployment and validation.';

GRANT OWNERSHIP ON SCHEMA <% target_db %>.<% target_schema %>
  TO ROLE R_SEMANTIC_ADMIN_<% env %> COPY CURRENT GRANTS;
GRANT OWNERSHIP ON SCHEMA <% exp_db %>.<% exp_schema %>
  TO ROLE R_SEMANTIC_ADMIN_<% env %> COPY CURRENT GRANTS;

USE ROLE R_SEMANTIC_ADMIN_<% env %>;

-- ------------------------------------------------------- deploy role (write)
GRANT USAGE ON DATABASE <% target_db %> TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT USAGE ON DATABASE <% exp_db %>    TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT USAGE ON SCHEMA <% target_db %>.<% target_schema %>
  TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT USAGE ON SCHEMA <% exp_db %>.<% exp_schema %>
  TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT CREATE SEMANTIC VIEW ON SCHEMA <% target_db %>.<% target_schema %>
  TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT CREATE AGENT ON SCHEMA <% exp_db %>.<% exp_schema %>
  TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT USAGE ON WAREHOUSE <% warehouse %> TO ROLE R_SEMANTIC_DEPLOY_<% env %>;

-- NOT granted to the deploy role, deliberately:
--   CREATE TABLE / VIEW / SCHEMA / DATABASE
--   any MANAGE GRANTS
--   any account-level privilege
--   MODIFY or MONITOR on the warehouse
--   DELETE / UPDATE / TRUNCATE on anything, including the ledger

-- ----------------------------------------------------- validate role (read)
GRANT USAGE ON DATABASE <% target_db %> TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
GRANT USAGE ON DATABASE <% exp_db %>    TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
GRANT USAGE, MONITOR ON SCHEMA <% target_db %>.<% target_schema %>
  TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
GRANT USAGE, MONITOR ON SCHEMA <% exp_db %>.<% exp_schema %>
  TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
GRANT SELECT ON FUTURE SEMANTIC VIEWS IN SCHEMA <% target_db %>.<% target_schema %>
  TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
GRANT SELECT ON ALL SEMANTIC VIEWS IN SCHEMA <% target_db %>.<% target_schema %>
  TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
GRANT USAGE ON WAREHOUSE <% warehouse %> TO ROLE R_SEMANTIC_VALIDATE_<% env %>;

-- OPEN ITEM (UNRESOLVED-5): confirm whether verify_only executes under a role
-- WITHOUT CREATE SEMANTIC VIEW. If it does not, create a disposable schema
-- and grant there - never widen access on the real target schema:
--   CREATE SCHEMA IF NOT EXISTS <% target_db %>.DS_ENT_VALIDATE;
--   GRANT USAGE, CREATE SEMANTIC VIEW ON SCHEMA <% target_db %>.DS_ENT_VALIDATE
--     TO ROLE R_SEMANTIC_VALIDATE_<% env %>;

-- ----------------------------------------------------------- grantor role
GRANT USAGE ON DATABASE <% target_db %> TO ROLE R_SEMANTIC_GRANTOR_<% env %>;
GRANT USAGE ON DATABASE <% exp_db %>    TO ROLE R_SEMANTIC_GRANTOR_<% env %>;
GRANT USAGE ON SCHEMA <% target_db %>.<% target_schema %>
  TO ROLE R_SEMANTIC_GRANTOR_<% env %>;
GRANT USAGE ON SCHEMA <% exp_db %>.<% exp_schema %>
  TO ROLE R_SEMANTIC_GRANTOR_<% env %>;
GRANT USAGE ON WAREHOUSE <% warehouse %> TO ROLE R_SEMANTIC_GRANTOR_<% env %>;

-- --------------------------------------------------------- ledger and lock
CREATE TABLE IF NOT EXISTS <% target_db %>.<% target_schema %>.SEMANTIC_DEPLOYMENT_LOG (
  deployment_id     VARCHAR       NOT NULL,
  environment       VARCHAR       NOT NULL,
  logical_name      VARCHAR       NOT NULL,
  artifact_type     VARCHAR       NOT NULL,
  bundle_version    VARCHAR       NOT NULL,
  git_commit        VARCHAR       NOT NULL,
  rendered_sha256   VARCHAR,
  target_fqn        VARCHAR,
  action            VARCHAR       NOT NULL,
  status            VARCHAR       NOT NULL,
  detail            VARCHAR,
  error_message     VARCHAR,
  change_request_id VARCHAR,
  pipeline_run_url  VARCHAR,
  deployed_by       VARCHAR       NOT NULL DEFAULT CURRENT_USER(),
  deployed_at       TIMESTAMP_LTZ NOT NULL DEFAULT CURRENT_TIMESTAMP()
) COMMENT = 'Append-only deployment ledger. System of record for live state.';

CREATE TABLE IF NOT EXISTS <% target_db %>.<% target_schema %>.SEMANTIC_DEPLOYMENT_LOCK (
  environment      VARCHAR       NOT NULL,
  deployment_id    VARCHAR       NOT NULL,
  locked_by        VARCHAR       NOT NULL,
  pipeline_run_url VARCHAR,
  locked_at        TIMESTAMP_LTZ NOT NULL,
  released_at      TIMESTAMP_LTZ
) COMMENT = 'Advisory deployment lock, one active row per environment.';

-- Append-only BY PRIVILEGE. A CI identity that can DELETE from its own audit
-- log is not an audit log.
GRANT INSERT, SELECT ON TABLE <% target_db %>.<% target_schema %>.SEMANTIC_DEPLOYMENT_LOG
  TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
GRANT SELECT ON TABLE <% target_db %>.<% target_schema %>.SEMANTIC_DEPLOYMENT_LOG
  TO ROLE R_SEMANTIC_VALIDATE_<% env %>;
GRANT INSERT, SELECT, UPDATE ON TABLE <% target_db %>.<% target_schema %>.SEMANTIC_DEPLOYMENT_LOCK
  TO ROLE R_SEMANTIC_DEPLOY_<% env %>;
