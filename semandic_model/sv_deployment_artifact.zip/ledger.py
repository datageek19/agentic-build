"""Deployment ledger and advisory lock.

The ledger is the system of record for what is live in each environment. It is
append-only BY PRIVILEGE: the deploy role holds INSERT and SELECT, never
UPDATE or DELETE. A CI identity that can delete its own audit log is not an
audit log.

Three consumers: change detection, drift detection, and audit.
"""
from __future__ import annotations

import argparse
import contextlib
import json
import os
import sys
import uuid
from datetime import datetime, timezone

DDL_LOG = """
CREATE TABLE IF NOT EXISTS IDENTIFIER(%(log)s) (
  deployment_id      VARCHAR        NOT NULL,
  environment        VARCHAR        NOT NULL,
  logical_name       VARCHAR        NOT NULL,
  artifact_type      VARCHAR        NOT NULL,
  bundle_version     VARCHAR        NOT NULL,
  git_commit         VARCHAR        NOT NULL,
  rendered_sha256    VARCHAR,
  target_fqn         VARCHAR,
  action             VARCHAR        NOT NULL,
  status             VARCHAR        NOT NULL,
  detail             VARCHAR,
  error_message      VARCHAR,
  change_request_id  VARCHAR,
  pipeline_run_url   VARCHAR,
  deployed_by        VARCHAR        NOT NULL DEFAULT CURRENT_USER(),
  deployed_at        TIMESTAMP_LTZ  NOT NULL DEFAULT CURRENT_TIMESTAMP()
)
"""

DDL_LOCK = """
CREATE TABLE IF NOT EXISTS IDENTIFIER(%(lock)s) (
  environment      VARCHAR       NOT NULL,
  deployment_id    VARCHAR       NOT NULL,
  locked_by        VARCHAR       NOT NULL,
  pipeline_run_url VARCHAR,
  locked_at        TIMESTAMP_LTZ NOT NULL,
  released_at      TIMESTAMP_LTZ
)
"""


def ensure_tables(cur, cfg) -> None:
    cur.execute(DDL_LOG % {"log": f"'{cfg.ledger_log_fqn}'"})
    cur.execute(DDL_LOCK % {"lock": f"'{cfg.ledger_lock_fqn}'"})


def new_deployment_id() -> str:
    return f"{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:8]}"


def record(cur, cfg, *, deployment_id: str, artifact, status: str,
           detail: str = "", error: str = "", change_request: str = "",
           run_url: str = "") -> None:
    target = ""
    if artifact.target:
        schema = (cfg.schema_exp_fqn
                  if artifact.target.get("schema_token") == "target_schema_exp"
                  else cfg.schema_bi_fqn)
        target = f"{schema}.{artifact.logical_name}"
    cur.execute(
        f"INSERT INTO {cfg.ledger_log_fqn} "
        "(deployment_id, environment, logical_name, artifact_type, "
        " bundle_version, git_commit, rendered_sha256, target_fqn, action, "
        " status, detail, error_message, change_request_id, pipeline_run_url) "
        "VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)",
        (deployment_id, cfg.environment, artifact.logical_name, artifact.type,
         cfg.bundle_version, cfg.git_commit, artifact.rendered_sha256, target,
         artifact.action, status, detail[:4000], error[:4000],
         change_request, run_url),
    )


def live_shas(cur, cfg) -> dict[str, str]:
    """Latest successfully deployed rendered sha per logical_name."""
    cur.execute(
        "SELECT logical_name, rendered_sha256 FROM ("
        "  SELECT logical_name, rendered_sha256,"
        "         ROW_NUMBER() OVER (PARTITION BY logical_name"
        "                            ORDER BY deployed_at DESC) AS rn"
        f"  FROM {cfg.ledger_log_fqn}"
        "   WHERE environment = %s AND status = 'SUCCESS' AND action = 'DEPLOYED'"
        ") WHERE rn = 1",
        (cfg.environment,),
    )
    return {r[0]: r[1] for r in cur.fetchall() if r[1]}


def current_state(cur, cfg) -> list[tuple]:
    cur.execute(
        "SELECT logical_name, bundle_version, git_commit, deployed_at, status "
        "FROM ("
        "  SELECT logical_name, bundle_version, git_commit, deployed_at, status,"
        "         ROW_NUMBER() OVER (PARTITION BY logical_name"
        "                            ORDER BY deployed_at DESC) AS rn"
        f"  FROM {cfg.ledger_log_fqn} WHERE environment = %s"
        ") WHERE rn = 1 ORDER BY logical_name",
        (cfg.environment,),
    )
    return cur.fetchall()


@contextlib.contextmanager
def advisory_lock(cur, cfg, deployment_id: str, run_url: str = ""):
    """Serialise deployments per environment inside Snowflake.

    CI-level concurrency groups are necessary but not sufficient: a developer
    with CREATE SEMANTIC VIEW, a CoCo session, or a Snowsight editor can race
    the pipeline. This lock makes the collision visible and named.
    """
    cur.execute(
        f"SELECT deployment_id, locked_by, pipeline_run_url, locked_at "
        f"FROM {cfg.ledger_lock_fqn} "
        "WHERE environment = %s AND released_at IS NULL",
        (cfg.environment,),
    )
    held = cur.fetchall()
    if held:
        d, who, url, when = held[0]
        raise RuntimeError(
            f"deployment lock held for {cfg.environment} by {who} "
            f"(deployment {d}, since {when}). Run: {url or 'unknown'}. "
            f"If that run is dead, use scripts/breakglass_unlock.py.")

    cur.execute(
        f"INSERT INTO {cfg.ledger_lock_fqn} "
        "(environment, deployment_id, locked_by, pipeline_run_url, locked_at) "
        "VALUES (%s,%s,CURRENT_USER(),%s,CURRENT_TIMESTAMP())",
        (cfg.environment, deployment_id, run_url),
    )
    try:
        yield
    finally:
        cur.execute(
            f"UPDATE {cfg.ledger_lock_fqn} SET released_at = CURRENT_TIMESTAMP() "
            "WHERE environment = %s AND deployment_id = %s",
            (cfg.environment, deployment_id),
        )


def _cli() -> int:
    from lib import config, session  # noqa: PLC0415

    ap = argparse.ArgumentParser(prog="ledger.py")
    ap.add_argument("command", choices=["state", "history", "export", "summarise"])
    ap.add_argument("--environment")
    ap.add_argument("--deployment-id")
    ap.add_argument("--limit", type=int, default=20)
    ap.add_argument("--out")
    ap.add_argument("--log")
    ap.add_argument("--format", default="table", choices=["table", "json"])
    args = ap.parse_args()

    if args.command == "summarise":
        if not args.log or not os.path.exists(args.log):
            return 0
        rows = [json.loads(line) for line in open(args.log) if line.strip()]
        print("\n| Artifact | Phase | Action | Status |")
        print("|---|---|---|---|")
        for r in rows:
            print(f"| `{r.get('logical_name','')}` | {r.get('phase','')} "
                  f"| {r.get('action','')} | {r.get('status','')} |")
        return 0

    cfg = config.load(args.environment)
    with session.connect(cfg) as conn:
        cur = conn.cursor()
        ensure_tables(cur, cfg)
        if args.command == "state":
            rows = current_state(cur, cfg)
            if args.format == "json":
                print(json.dumps([list(map(str, r)) for r in rows], indent=2))
            else:
                print(f"{'logical_name':40} {'bundle':14} {'commit':10} status")
                for n, b, c, _t, s in rows:
                    print(f"{n:40} {b:14} {(c or '')[:9]:10} {s}")
        elif args.command == "history":
            cur.execute(
                "SELECT deployment_id, bundle_version, git_commit, action, "
                "status, change_request_id, deployed_at "
                f"FROM {cfg.ledger_log_fqn} WHERE environment = %s "
                "ORDER BY deployed_at DESC LIMIT %s",
                (cfg.environment, args.limit))
            for r in cur.fetchall():
                print(" | ".join(str(x) for x in r))
        elif args.command == "export":
            cur.execute(
                f"SELECT * FROM {cfg.ledger_log_fqn} "
                "WHERE environment = %s AND pipeline_run_url ILIKE %s",
                (cfg.environment, f"%{args.deployment_id}%"))
            cols = [d[0] for d in cur.description]
            data = [dict(zip(cols, map(str, r))) for r in cur.fetchall()]
            out = json.dumps(data, indent=2)
            if args.out:
                open(args.out, "w").write(out)
            else:
                print(out)
    return 0


if __name__ == "__main__":
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    raise SystemExit(_cli())
