#!/usr/bin/env python3
"""Force-release a stale deployment lock. Requires an incident reference.

Refuses to act if the holding run appears to still be alive - the operator
must confirm the run is dead before overriding.
"""
from __future__ import annotations

import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from lib import config, ledger, session  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--environment", required=True,
                    choices=("dev", "test", "prod"))
    ap.add_argument("--incident", required=True)
    ap.add_argument("--reason", required=True)
    ap.add_argument("--confirm-run-dead", action="store_true",
                    help="required: you have verified the holding run is dead")
    args = ap.parse_args()

    cfg = config.load(args.environment)
    with session.connect(cfg) as conn:
        cur = conn.cursor()
        ledger.ensure_tables(cur, cfg)
        cur.execute(
            f"SELECT deployment_id, locked_by, pipeline_run_url, locked_at "
            f"FROM {cfg.ledger_lock_fqn} "
            "WHERE environment = %s AND released_at IS NULL",
            (cfg.environment,))
        held = cur.fetchall()
        if not held:
            print(f"no lock held for {args.environment}; nothing to do")
            return 0
        for d, who, url, when in held:
            print(f"lock: deployment={d} by={who} since={when} run={url}")
        if not args.confirm_run_dead:
            sys.stderr.write(
                "\nrefusing to release. Verify the holding run has terminated, "
                "then re-run with --confirm-run-dead.\n")
            return 1
        cur.execute(
            f"UPDATE {cfg.ledger_lock_fqn} SET released_at = CURRENT_TIMESTAMP() "
            "WHERE environment = %s AND released_at IS NULL",
            (cfg.environment,))

        class _A:
            logical_name = "LOCK_FORCE_RELEASED"
            type = "breakglass"
            target = None
            action = "LOCK_FORCE_RELEASED"
            rendered_sha256 = None
        ledger.record(cur, cfg, deployment_id=ledger.new_deployment_id(),
                      artifact=_A(), status="SUCCESS",
                      detail=f"incident={args.incident} reason={args.reason}")
    print("\nlock released. A crashed run almost certainly left a partial "
          "deployment: check `ledger.py state` and converge in one direction.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
