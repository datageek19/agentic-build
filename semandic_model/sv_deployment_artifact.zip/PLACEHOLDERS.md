# Placeholder register

Every value below is genuinely organisation-specific. Nothing else in this
repository needs editing to adapt it.

## A. Snowflake — supplied as secrets, never committed

Per environment (`dev`, `test`, `prod`). Store in Azure Key Vault (ADO) or as
GitHub **environment** secrets. Bound in
`configuration/environments/<env>.yaml` via `{from_env: NAME}`.

| Secret | Populate with | Example shape |
|---|---|---|
| `SF_ACCOUNT` | Snowflake account identifier | `myorg-myaccount` |
| `SF_WAREHOUSE` | Deployment/validation warehouse | `WH_SEMANTIC_PROD` |
| `SF_DEPLOY_USER` | From `bootstrap/01` | `SVC_SEMANTIC_DEPLOY_PROD` |
| `SF_DEPLOY_ROLE` | From `bootstrap/01` | `R_SEMANTIC_DEPLOY_PROD` |
| `SF_VALIDATE_USER` | From `bootstrap/01` | `SVC_SEMANTIC_VALIDATE_PROD` |
| `SF_VALIDATE_ROLE` | From `bootstrap/01` | `R_SEMANTIC_VALIDATE_PROD` |
| `SF_GRANTOR_USER` | From `bootstrap/01` | `SVC_SEMANTIC_GRANTOR_PROD` |
| `SF_GRANTOR_ROLE` | From `bootstrap/01` | `R_SEMANTIC_GRANTOR_PROD` |
| `SF_LAND_SOURCE_DB` | Land source database for this env | *(source system)* |
| `SF_LAND_SOURCE_SCHEMA` | Land source schema | *(source system)* |
| `SF_OPS_SOURCE_DB` | Operations source database | *(source system)* |
| `SF_OPS_SOURCE_SCHEMA` | Operations source schema | *(source system)* |
| `SF_TARGET_DB_BI` | Semantic view database | *(your analytics DB)* |
| `SF_TARGET_SCHEMA_BI` | Semantic view schema | *(your BI schema)* |
| `SF_TARGET_DB_EXP` | Cortex Agent database | *(your agent DB)* |
| `SF_TARGET_SCHEMA_EXP` | Cortex Agent schema | *(your agent schema)* |
| `SF_CONSUMER_ROLES` | Comma-separated consumer roles | `R_SEMANTIC_CONSUMER_LAND_PROD` |

Database and schema names are marked **secret**, not variable. On a client
engagement, source topology is customer information and should not appear in
build logs or in Git.

Additionally, for the build stage only (which renders all three environments
at once), the same source and target tokens with an `_DEV` / `_TEST` / `_PROD`
suffix — for example `SF_LAND_SOURCE_DB_PROD`. Put these in a single
`sf-semantic-build` variable group (ADO) or repository-level secrets scoped to
the build workflow (GitHub).

## B. Key-pair fallback (only if WIF is unavailable)

| Secret | Notes |
|---|---|
| `SF_PRIVATE_KEY_RAW` | PEM content, RSA-4096. Must be **absent** when WIF is active |
| `SF_PRIVATE_KEY_PASSPHRASE` | Optional |
| `USE_KEYPAIR_FALLBACK` | Variable, `false` by default |

## C. Azure DevOps

| Item | Populate with |
|---|---|
| `AZ_TENANT_ID` | Entra tenant ID, used in the WIF issuer URL |
| `ADO_ORG` | Azure DevOps organisation name |
| `ADO_PROJECT` | Azure DevOps project name |
| `ADO_SERVICE_CONNECTION` | e.g. `sf-semantic-wif-prod`; must match the federated credential subject exactly |
| App registration names | `sf-semantic-wif-{dev,test,prod}` |
| Variable groups | `sf-semantic-{dev,test,prod}`, `sf-semantic-build` |

Federated credential on each App Registration:
- Issuer: `https://vstoken.dev.azure.com/<AZ_TENANT_ID>`
- Subject: `sc://<ADO_ORG>/<ADO_PROJECT>/<ADO_SERVICE_CONNECTION>`
- Audience: `api://AzureADTokenExchange`

## D. GitHub

| Item | Populate with |
|---|---|
| `GH_ORG`, `GH_REPO` | Used in the OIDC subject claim |
| Environments | `sf-dev-verify`, `sf-dev`, `sf-test`, `sf-prod` |
| Repository variables | `PYTHON_VERSION`, `SNOWFLAKE_CLI_VERSION` |

Subject claim per environment:
`repo:<GH_ORG>/<GH_REPO>:environment:sf-<env>`

## E. Repository metadata

| File | What to replace |
|---|---|
| `CODEOWNERS` | Every `@PLACEHOLDER-org/...` team handle |
| `bootstrap/03_source_grants.sql` | `<% source_owner_role %>` — the source database's owning role |
| `bootstrap/04_consumer_roles.sql` | `<% consumer_parent_role %>` |
| `bootstrap/01_roles_and_users.sql` | `NP_CI_EGRESS` network policy must be created first |

## F. Model content still to be supplied

| Placeholder | Location |
|---|---|
| Full participation model (10 tables, 8 relationships, 106 attributes) | `semantic_views/land/participation_interests.sv.yaml` — currently abridged to 4 tables |
| Agreement acreage model | `semantic_views/land/agreement_acreage.sv.yaml` — stub |
| Contracts/obligations model | `semantic_views/land/contracts_obligations.sv.yaml` — stub |
| Operations allocated volumes model | `semantic_views/ops/allocated_vols.sv.yaml` — stub |
| Agent specification body | `agents/land_quorum_agent.agent.yaml` — inferred shape |
| OPS source contract columns | `dependencies/source_contracts.yaml` → `ops_core` |
| Golden-set questions and expected values | `tests/golden/*.golden.yaml` |
