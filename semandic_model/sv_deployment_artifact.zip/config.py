"""Configuration loading and token resolution.

Loads configuration/common.yaml plus one environment file, resolves every
{from_env: VAR} binding from the process environment, and fails loudly on any
missing binding. No identifier ever appears in the repository.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

REPO = Path(__file__).resolve().parents[2]
COMMON = REPO / "configuration" / "common.yaml"
ENV_DIR = REPO / "configuration" / "environments"
VALID_ENVIRONMENTS = ("dev", "test", "prod")


class ConfigError(RuntimeError):
    pass


def _resolve(node: Any, path: str, missing: list[str]) -> Any:
    """Recursively replace {from_env: VAR} with the environment value."""
    if isinstance(node, dict):
        if set(node.keys()) <= {"from_env", "secret"} and "from_env" in node:
            var = node["from_env"]
            val = os.environ.get(var)
            if val is None or val == "":
                missing.append(f"{path} <- ${var}")
                return None
            return val
        return {k: _resolve(v, f"{path}.{k}", missing) for k, v in node.items()}
    if isinstance(node, list):
        return [_resolve(v, f"{path}[{i}]", missing) for i, v in enumerate(node)]
    return node


@dataclass
class Config:
    environment: str
    connection_name: str
    connection: dict
    validate_connection: dict
    grantor_connection: dict
    tokens: dict
    grants: dict
    policy: dict
    deploy: dict
    ledger: dict
    phases: list
    bundle_version: str = "unknown"
    git_commit: str = "unknown"
    declared_tokens: dict = field(default_factory=dict)

    def token(self, name: str) -> str:
        if name not in self.tokens or self.tokens[name] is None:
            raise ConfigError(f"token '{name}' is not bound in {self.environment}")
        return self.tokens[name]

    @property
    def schema_bi_fqn(self) -> str:
        return f"{self.token('target_db_bi')}.{self.token('target_schema_bi')}"

    @property
    def schema_exp_fqn(self) -> str:
        return f"{self.token('target_db_exp')}.{self.token('target_schema_exp')}"

    @property
    def ledger_log_fqn(self) -> str:
        return f"{self.schema_bi_fqn}.{self.ledger['log_table']}"

    @property
    def ledger_lock_fqn(self) -> str:
        return f"{self.schema_bi_fqn}.{self.ledger['lock_table']}"

    @property
    def consumer_roles(self) -> list[str]:
        raw = self.grants.get("consumer_roles") or ""
        return [r.strip() for r in raw.split(",") if r.strip()]


def load(environment: str, *, bundle_version: str = "unknown",
         git_commit: str = "unknown", require_tokens: bool = True) -> Config:
    if environment not in VALID_ENVIRONMENTS:
        raise ConfigError(
            f"unknown environment '{environment}'; expected one of "
            f"{VALID_ENVIRONMENTS}")

    common = yaml.safe_load(COMMON.read_text())
    env_raw = yaml.safe_load((ENV_DIR / f"{environment}.yaml").read_text())

    declared = common.get("tokens", {})
    bound = set(env_raw.get("tokens", {}).keys())
    undeclared = bound - declared.keys()
    if undeclared:
        raise ConfigError(
            f"{environment}.yaml binds tokens absent from common.yaml: "
            f"{sorted(undeclared)}")
    unbound = {k for k, v in declared.items() if v.get("required")} - bound
    if unbound:
        raise ConfigError(
            f"{environment}.yaml does not bind required tokens: {sorted(unbound)}")

    missing: list[str] = []
    resolved = _resolve(env_raw, environment, missing)
    if missing and require_tokens:
        raise ConfigError(
            "unresolved configuration bindings (set these environment "
            "variables):\n  " + "\n  ".join(missing))

    return Config(
        environment=environment,
        connection_name=common["connection_name"],
        connection=resolved.get("connection") or {},
        validate_connection=resolved.get("validate_connection") or {},
        grantor_connection=resolved.get("grantor_connection") or {},
        tokens=resolved.get("tokens") or {},
        grants=resolved.get("grants") or {},
        policy=resolved.get("policy") or {},
        deploy=common["deploy"],
        ledger=common["ledger"],
        phases=common["phases"],
        bundle_version=bundle_version,
        git_commit=git_commit,
        declared_tokens=declared,
    )
