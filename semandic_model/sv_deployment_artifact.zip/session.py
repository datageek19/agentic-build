"""Snowflake session factory.

Primary: workload identity federation (OIDC). The Snowflake CLI CI
integrations place the platform OIDC token in SNOWFLAKE_TOKEN; the Python
connector accepts it via authenticator=WORKLOAD_IDENTITY with
workload_identity_provider=OIDC.

Fallback: key-pair (SNOWFLAKE_JWT). Present so the design survives a blocked
marketplace extension, but inert unless SF_PRIVATE_KEY_RAW is set.

Passwords are not supported by this module, by design.
"""
from __future__ import annotations

import json
import os
from contextlib import contextmanager

import snowflake.connector

PREFIX = "SNOWFLAKE_CONNECTIONS_SEMANTIC_"


class AuthError(RuntimeError):
    pass


def _required(name: str) -> str:
    val = os.environ.get(name)
    if not val:
        raise AuthError(
            f"missing required environment variable {name}. Set it from the "
            f"environment's secret store; never hard-code it.")
    return val


def _auth_kwargs() -> dict:
    token = os.environ.get("SNOWFLAKE_TOKEN")
    if token:
        return {
            "authenticator": "WORKLOAD_IDENTITY",
            "workload_identity_provider": "OIDC",
            "token": token,
        }
    raw_key = os.environ.get(PREFIX + "PRIVATE_KEY_RAW")
    if raw_key:
        kwargs = {"authenticator": "SNOWFLAKE_JWT",
                  "private_key": raw_key.encode("utf-8")}
        passphrase = os.environ.get("PRIVATE_KEY_PASSPHRASE")
        if passphrase:
            kwargs["private_key_file_pwd"] = passphrase
        return kwargs
    raise AuthError(
        "no usable credential. Expected SNOWFLAKE_TOKEN (WIF/OIDC, primary) "
        f"or {PREFIX}PRIVATE_KEY_RAW (key-pair, fallback). "
        "Password authentication is not supported.")


@contextmanager
def connect(cfg, *, role: str | None = None, user: str | None = None):
    """Open a session. Never include connection parameters in exception text:
    CI log masking does not cover values a script formats into an error."""
    params = {
        "account": _required(PREFIX + "ACCOUNT"),
        "user": user or _required(PREFIX + "USER"),
        "role": role or _required(PREFIX + "ROLE"),
        "warehouse": _required(PREFIX + "WAREHOUSE"),
        "client_session_keep_alive": False,
        "session_parameters": {
            "QUERY_TAG": json.dumps({
                "pipeline": "semantic-layer",
                "env": cfg.environment,
                "bundle": cfg.bundle_version,
                "commit": cfg.git_commit,
            }),
            "STATEMENT_TIMEOUT_IN_SECONDS":
                cfg.deploy["statement_timeout_seconds"],
        },
    }
    params.update(_auth_kwargs())

    try:
        conn = snowflake.connector.connect(**params)
    except Exception as exc:
        raise AuthError(f"Snowflake connection failed: {type(exc).__name__}. "
                        f"Run `snow connection test` to isolate. "
                        f"Detail: {exc}") from None
    try:
        yield conn
    finally:
        conn.close()
